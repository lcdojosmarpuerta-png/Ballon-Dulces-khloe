import { Client, InventoryItem, InvoiceDocument, RentalInspection, PagoMovilConfig } from '../types';

export const INITIAL_CLIENTS: Client[] = [
  {
    id: 'cli-1',
    name: 'Mariana Mendoza',
    cedulaRif: 'V-24589123-1',
    phone: '+584141234567',
    address: 'Av. Las Delicias, Residencias Los Álamos, Apto 4B',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'cli-2',
    name: 'Carlos Eduardo Peña',
    cedulaRif: 'V-18965412-8',
    phone: '+584249876543',
    address: 'Urb. San Jacinto, Manzana D, Casa 12',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  },
  {
    id: 'cli-3',
    name: 'Valentina Rodríguez',
    cedulaRif: 'V-27341890-5',
    phone: '+584125558899',
    address: 'Calle Los Samanes, Quinta Mi Refugio, El Bosque',
    createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
  }
];

export const INITIAL_INVENTORY: InventoryItem[] = [
  {
    id: 'inv-1',
    name: 'Arco Orgánico de Globos Rosas & Blancos',
    category: 'Decoración',
    quantity: 12,
    price: 45.0,
    imageUrl: 'https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=500&auto=format&fit=crop&q=80',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'inv-2',
    name: 'Mesa Candy Bar Vintage Cilíndrica (Set x3)',
    category: 'Mobiliario',
    quantity: 8,
    price: 35.0,
    imageUrl: 'https://images.unsplash.com/photo-1513151233558-d860c5398176?w=500&auto=format&fit=crop&q=80',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'inv-3',
    name: 'Bandeja Pastelera Dulces Finos y Trufas (50 uds)',
    category: 'Comestibles',
    quantity: 25,
    price: 28.0,
    imageUrl: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?w=500&auto=format&fit=crop&q=80',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'inv-4',
    name: 'Bandeja Tequeños Gourmet de Queso Blanco (100 uds)',
    category: 'Pasapalos',
    quantity: 30,
    price: 32.0,
    imageUrl: 'https://images.unsplash.com/photo-1541592106381-b31e9677c0e5?w=500&auto=format&fit=crop&q=80',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'inv-5',
    name: 'Corneta Activa Bluetooth 15" con Trípode y Micrófono',
    category: 'Equipos de sonido',
    quantity: 6,
    price: 40.0,
    imageUrl: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=500&auto=format&fit=crop&q=80',
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'inv-6',
    name: 'Sillas Tiffany Blancas con Cojín Acolchado',
    category: 'Mobiliario',
    quantity: 120,
    price: 2.5,
    imageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?w=500&auto=format&fit=crop&q=80',
    updatedAt: new Date().toISOString(),
  }
];

export const INITIAL_INVOICES: InvoiceDocument[] = [
  {
    id: 'doc-1',
    documentNumber: 'FACT-001',
    type: 'Factura',
    status: 'Pagada',
    paymentMethod: 'Pago Móvil',
    clientId: 'cli-1',
    clientName: 'Mariana Mendoza',
    clientCedulaRif: 'V-24589123-1',
    clientPhone: '+584141234567',
    clientAddress: 'Av. Las Delicias, Residencias Los Álamos, Apto 4B',
    items: [
      {
        id: 'it-1',
        inventoryId: 'inv-1',
        name: 'Arco Orgánico de Globos Rosas & Blancos',
        quantity: 1,
        unitPrice: 45,
        total: 45,
      },
      {
        id: 'it-2',
        inventoryId: 'inv-3',
        name: 'Bandeja Pastelera Dulces Finos y Trufas (50 uds)',
        quantity: 2,
        unitPrice: 28,
        total: 56,
      }
    ],
    subtotalUSD: 101,
    ivaRate: 0.16,
    ivaUSD: 16.16,
    totalUSD: 117.16,
    bcvRate: 36.5,
    totalBs: 4276.34,
    notes: 'Entrega para fiesta infantil el sábado a las 2:00 PM.',
    issueDate: new Date().toISOString().slice(0, 10),
    createdAt: new Date().toISOString(),
  },
  {
    id: 'doc-2',
    documentNumber: 'NE-002',
    type: 'Nota de Entrega',
    status: 'Abonada',
    clientId: 'cli-2',
    clientName: 'Carlos Eduardo Peña',
    clientPhone: '+584249876543',
    clientAddress: 'Urb. San Jacinto, Manzana D, Casa 12',
    items: [
      {
        id: 'it-3',
        inventoryId: 'inv-4',
        name: 'Bandeja Tequeños Gourmet de Queso Blanco (100 uds)',
        quantity: 2,
        unitPrice: 32,
        total: 64,
      },
      {
        id: 'it-4',
        inventoryId: 'inv-5',
        name: 'Corneta Activa Bluetooth 15" con Trípode',
        quantity: 1,
        unitPrice: 40,
        total: 40,
      }
    ],
    subtotalUSD: 104,
    ivaRate: 0,
    ivaUSD: 0,
    totalUSD: 104,
    bcvRate: 36.5,
    totalBs: 3796.00,
    notes: 'Nota de entrega sin impuestos. Depósito 50% abonado.',
    issueDate: new Date(Date.now() - 86400000 * 3).toISOString().slice(0, 10),
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
  }
];

export const DEFAULT_PAGO_MOVIL: PagoMovilConfig = {
  bankName: 'Banco de Venezuela (0102)',
  bankCode: '0102',
  idNumber: 'V-26136645',
  phone: '04141234567',
  accountHolder: 'Lcdo. Josmar Puerta',
  notes: 'Favor enviar capture del comprobante con número de referencia bancaria visible.',
};

export const INITIAL_RENTALS: RentalInspection[] = [
  {
    id: 'ALQ-2026-001',
    invoiceId: 'doc-1',
    documentNumber: 'FACT-001',
    clientId: 'cli-1',
    clientName: 'Mariana Mendoza',
    clientPhone: '+584141234567',
    clientCedulaRif: 'V-24589123-1',
    eventLocation: 'Salón de Fiestas Los Álamos, Av. Las Delicias',
    dispatchDate: new Date().toISOString().slice(0, 10),
    expectedReturnDate: new Date(Date.now() + 86400000).toISOString().slice(0, 10),
    depositAmountUSD: 50.0,
    status: 'En Evento (Calle)',
    itemsDispatched: [
      { name: 'Sillas Tiffany Blancas con Cojín Acolchado', quantity: 20 },
      { name: 'Mesa Candy Bar Vintage Cilíndrica (Set x3)', quantity: 1 },
      { name: 'Arco Orgánico de Globos Rosas & Blancos', quantity: 1 }
    ],
    damages: [],
    totalDamageChargeUSD: 0,
    depositRefundUSD: 50.0,
    pendingChargeUSD: 0,
    inspectionNotes: 'Mobiliario despachado en perfectas condiciones y embalado.',
    inspectedBy: 'Lcdo. Josmar Puerta',
    createdAt: new Date().toISOString(),
  },
  {
    id: 'ALQ-2026-002',
    invoiceId: 'doc-2',
    documentNumber: 'NOTA-002',
    clientId: 'cli-2',
    clientName: 'Carlos Eduardo Peña',
    clientPhone: '+584249876543',
    clientCedulaRif: 'V-18965412-8',
    eventLocation: 'Urb. San Jacinto, Manzana D, Casa 12',
    dispatchDate: new Date(Date.now() - 86400000 * 2).toISOString().slice(0, 10),
    expectedReturnDate: new Date(Date.now() - 86400000).toISOString().slice(0, 10),
    actualReturnDate: new Date().toISOString().slice(0, 10),
    depositAmountUSD: 40.0,
    status: 'Devuelto Conforme',
    itemsDispatched: [
      { name: 'Corneta Activa Bluetooth 15" con Trípode', quantity: 1 }
    ],
    damages: [],
    totalDamageChargeUSD: 0,
    depositRefundUSD: 40.0,
    pendingChargeUSD: 0,
    inspectionNotes: 'Retirado a tiempo, equipo probado y sonido conforme. Garantía reintegrada al cliente.',
    inspectedBy: 'Lcdo. Josmar Puerta',
    inspectedAt: new Date().toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
  }
];
