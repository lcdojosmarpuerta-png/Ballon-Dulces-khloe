import * as XLSX from 'xlsx';
import { InvoiceDocument } from '../types';
import { getAccessToken } from './googleAuth';

/**
 * Exporta directamente a un archivo .xlsx para descarga en el navegador
 */
export function exportInvoicesToExcel(invoices: InvoiceDocument[], monthLabel: string = 'Mes_Actual') {
  const data = invoices.map((inv) => ({
    'ID / N° Documento': inv.documentNumber,
    'Tipo': inv.type,
    'Estado': inv.status,
    'Fecha de Emisión': inv.issueDate,
    'Cliente': inv.clientName,
    'Teléfono': inv.clientPhone,
    'Dirección': inv.clientAddress,
    'Subtotal (USD)': inv.subtotalUSD.toFixed(2),
    'IVA 16% (USD)': inv.ivaUSD.toFixed(2),
    'Total (USD)': inv.totalUSD.toFixed(2),
    'Tasa BCV (Bs/$)': inv.bcvRate.toFixed(2),
    'Total (Bs)': inv.totalBs.toFixed(2),
    'Observaciones': inv.notes || '',
    'Cantidad de Ítems': inv.items.reduce((acc, it) => acc + it.quantity, 0),
  }));

  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Reporte Facturación');

  // Ajuste automático de anchos de columna
  const colWidths = [
    { wch: 16 }, // N°
    { wch: 14 }, // Tipo
    { wch: 12 }, // Estado
    { wch: 14 }, // Fecha
    { wch: 22 }, // Cliente
    { wch: 16 }, // Telefono
    { wch: 28 }, // Dirección
    { wch: 14 }, // Subtotal
    { wch: 14 }, // IVA
    { wch: 14 }, // Total USD
    { wch: 14 }, // Tasa BCV
    { wch: 16 }, // Total Bs
    { wch: 30 }, // Observaciones
    { wch: 16 }, // Cantidad
  ];
  worksheet['!cols'] = colWidths;

  const fileName = `Reporte_Ballon_Dulces_Klhoe_${monthLabel.replace(/\s+/g, '_')}.xlsx`;
  XLSX.writeFile(workbook, fileName);
}

/**
 * Exporta a Google Sheets usando la API de Google Sheets y Drive
 */
export async function exportInvoicesToGoogleSheets(
  invoices: InvoiceDocument[],
  title: string = 'Reporte Mensual Ballón Dulces Klhoe'
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const token = await getAccessToken();
  if (!token) {
    throw new Error('Debes iniciar sesión con Google para sincronizar con Google Sheets.');
  }

  // 1. Crear nueva hoja de cálculo
  const createRes = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      properties: {
        title: `${title} (${new Date().toLocaleDateString('es-VE')})`,
      },
      sheets: [
        {
          properties: {
            title: 'Movimientos del Mes',
            gridProperties: {
              frozenRowCount: 1,
            },
          },
        },
      ],
    }),
  });

  if (!createRes.ok) {
    const err = await createRes.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'Error al crear hoja en Google Sheets');
  }

  const sheetData = await createRes.json();
  const spreadsheetId = sheetData.spreadsheetId;
  const spreadsheetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // 2. Preparar valores de cabecera y filas
  const header = [
    'N° Documento',
    'Tipo',
    'Estado',
    'Fecha Emisión',
    'Cliente',
    'Teléfono',
    'Dirección',
    'Subtotal ($)',
    'IVA 16% ($)',
    'Total ($)',
    'Tasa BCV (Bs)',
    'Total (Bs)',
    'Observaciones',
  ];

  const rows = invoices.map((inv) => [
    inv.documentNumber,
    inv.type,
    inv.status,
    inv.issueDate,
    inv.clientName,
    inv.clientPhone,
    inv.clientAddress,
    inv.subtotalUSD,
    inv.ivaUSD,
    inv.totalUSD,
    inv.bcvRate,
    inv.totalBs,
    inv.notes || '',
  ]);

  const values = [header, ...rows];

  // 3. Escribir valores en la hoja
  const updateRes = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/'Movimientos del Mes'!A1?valueInputOption=USER_ENTERED`,
    {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        values,
      }),
    }
  );

  if (!updateRes.ok) {
    console.warn('Advertencia al escribir filas en Google Sheets');
  }

  return { spreadsheetId, spreadsheetUrl };
}
