import React, { useState } from 'react';
import { 
  ShieldCheck, 
  AlertTriangle, 
  Clock, 
  CheckCircle2, 
  Plus, 
  Search, 
  ArrowLeftRight, 
  Building2, 
  Phone, 
  Calendar, 
  DollarSign, 
  Printer, 
  FileText, 
  X, 
  Trash2, 
  MessageCircle,
  HelpCircle,
  Truck,
  Copy,
  Check
} from 'lucide-react';
import { 
  RentalInspection, 
  Client, 
  InventoryItem, 
  InvoiceDocument, 
  RentalStatus, 
  InspectionDamageItem 
} from '../types';

interface RentalsModuleProps {
  rentals: RentalInspection[];
  clients: Client[];
  inventory: InventoryItem[];
  invoices: InvoiceDocument[];
  bcvRate: number | null;
  onAddRental: (rental: RentalInspection) => void;
  onUpdateRental: (rental: RentalInspection) => void;
  onDeleteRental: (id: string) => void;
}

export const RentalsModule: React.FC<RentalsModuleProps> = ({
  rentals,
  clients,
  inventory,
  invoices,
  bcvRate,
  onAddRental,
  onUpdateRental,
  onDeleteRental,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modals
  const [showNewRentalModal, setShowNewRentalModal] = useState(false);
  const [inspectingRental, setInspectingRental] = useState<RentalInspection | null>(null);
  const [viewingActa, setViewingActa] = useState<RentalInspection | null>(null);

  // Nuevo alquiler form state
  const [selectedClientId, setSelectedClientId] = useState('');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState('');
  const [eventLocation, setEventLocation] = useState('');
  const [dispatchDate, setDispatchDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [expectedReturnDate, setExpectedReturnDate] = useState(() => {
    return new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  });
  const [depositUSD, setDepositUSD] = useState<number>(50);
  const [dispatchedItems, setDispatchedItems] = useState<{ inventoryId?: string; name: string; quantity: number }[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemQty, setNewItemQty] = useState(1);

  // Formulario de Inspección
  const [inspectionResult, setInspectionResult] = useState<'perfect' | 'damages'>('perfect');
  const [damagesList, setDamagesList] = useState<InspectionDamageItem[]>([]);
  const [inspectionNotes, setInspectionNotes] = useState('');
  const [newDamageItemName, setNewDamageItemName] = useState('');
  const [newDamageType, setNewDamageType] = useState<InspectionDamageItem['damageType']>('Rotura');
  const [newDamageSeverity, setNewDamageSeverity] = useState<InspectionDamageItem['severity']>('Grave');
  const [newDamageCost, setNewDamageCost] = useState<number>(10);
  const [newDamageNote, setNewDamageNote] = useState('');

  // Recordatorio de Recolección para el Chofer / Encargado de Transporte
  const [reminderRental, setReminderRental] = useState<RentalInspection | null>(null);
  const [driverName, setDriverName] = useState<string>('Chofer / Encargado de Recolección');
  const [driverPhone, setDriverPhone] = useState<string>('');
  const [pickupTime, setPickupTime] = useState<string>('10:00 PM');
  const [pickupNotes, setPickupNotes] = useState<string>('Llevar mantas protectoras, revisar cojines y contar piezas antes de cargar.');
  const [copiedReminder, setCopiedReminder] = useState<boolean>(false);

  const currentRate = bcvRate || 36.5;

  // Filtrado
  const filteredRentals = rentals.filter((r) => {
    const matchesFilter =
      filterStatus === 'all'
        ? true
        : filterStatus === 'calle'
        ? r.status === 'En Evento (Calle)'
        : filterStatus === 'conforme'
        ? r.status === 'Devuelto Conforme'
        : filterStatus === 'danos'
        ? r.status === 'Devuelto con Daños'
        : true;

    const matchesSearch =
      r.clientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.documentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.eventLocation.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.itemsDispatched.some((it) => it.name.toLowerCase().includes(searchTerm.toLowerCase()));

    return matchesFilter && matchesSearch;
  });

  // Métricas de Semáforo
  const activeRentals = rentals.filter((r) => r.status === 'En Evento (Calle)');
  const totalPiecesInStreet = activeRentals.reduce(
    (acc, curr) => acc + curr.itemsDispatched.reduce((iAcc, it) => iAcc + it.quantity, 0),
    0
  );
  const totalDepositHeldUSD = activeRentals.reduce((acc, curr) => acc + curr.depositAmountUSD, 0);

  // Manejo de carga de ítems desde Factura
  const handleSelectInvoice = (invId: string) => {
    setSelectedInvoiceId(invId);
    if (!invId) return;
    const inv = invoices.find((i) => i.id === invId);
    if (inv) {
      setSelectedClientId(inv.clientId);
      setEventLocation(inv.clientAddress || '');
      setDispatchedItems(
        inv.items.map((it) => ({
          inventoryId: it.inventoryId,
          name: it.name,
          quantity: it.quantity,
        }))
      );
    }
  };

  const handleAddItemToDispatch = () => {
    if (!newItemName.trim() || newItemQty <= 0) return;
    setDispatchedItems([...dispatchedItems, { name: newItemName.trim(), quantity: newItemQty }]);
    setNewItemName('');
    setNewItemQty(1);
  };

  const handleRemoveItemFromDispatch = (index: number) => {
    setDispatchedItems(dispatchedItems.filter((_, i) => i !== index));
  };

  const handleSaveNewRental = (e: React.FormEvent) => {
    e.preventDefault();
    const client = clients.find((c) => c.id === selectedClientId);
    if (!client && !selectedClientId) return;

    const clientName = client ? client.name : 'Cliente no especificado';
    const clientPhone = client ? client.phone : '';
    const clientCedulaRif = client ? client.cedulaRif : '';

    const newRental: RentalInspection = {
      id: `ALQ-${Date.now().toString().slice(-4)}`,
      invoiceId: selectedInvoiceId || undefined,
      documentNumber: selectedInvoiceId ? (invoices.find((i) => i.id === selectedInvoiceId)?.documentNumber || 'REC-ALQ') : `ALQ-${Date.now().toString().slice(-4)}`,
      clientId: selectedClientId,
      clientName,
      clientPhone,
      clientCedulaRif,
      eventLocation: eventLocation.trim() || 'Locación del cliente',
      dispatchDate,
      expectedReturnDate,
      depositAmountUSD: Number(depositUSD) || 0,
      status: 'En Evento (Calle)',
      itemsDispatched: dispatchedItems.length > 0 ? dispatchedItems : [{ name: 'Mobiliario General', quantity: 1 }],
      damages: [],
      totalDamageChargeUSD: 0,
      depositRefundUSD: Number(depositUSD) || 0,
      pendingChargeUSD: 0,
      inspectionNotes: 'Mobiliario despachado.',
      inspectedBy: 'Lcdo. Josmar Puerta',
      createdAt: new Date().toISOString(),
    };

    onAddRental(newRental);
    setShowNewRentalModal(false);
    // Reset
    setSelectedInvoiceId('');
    setSelectedClientId('');
    setEventLocation('');
    setDispatchedItems([]);
  };

  // Abrir modal de inspección para un alquiler
  const handleOpenInspection = (rental: RentalInspection) => {
    setInspectingRental(rental);
    setInspectionResult('perfect');
    setDamagesList([]);
    setInspectionNotes(rental.inspectionNotes || '');
  };

  const handleAddDamageItem = () => {
    if (!newDamageItemName.trim() || newDamageCost <= 0) return;
    const newDamage: InspectionDamageItem = {
      id: `dmg-${Date.now()}`,
      itemName: newDamageItemName.trim(),
      damageType: newDamageType,
      severity: newDamageSeverity,
      chargeUSD: Number(newDamageCost) || 0,
      notes: newDamageNote.trim() || undefined,
    };
    setDamagesList([...damagesList, newDamage]);
    setNewDamageItemName('');
    setNewDamageCost(10);
    setNewDamageNote('');
  };

  const handleRemoveDamage = (id: string) => {
    setDamagesList(damagesList.filter((d) => d.id !== id));
  };

  const handleSaveInspection = () => {
    if (!inspectingRental) return;

    const totalDamage = damagesList.reduce((acc, curr) => acc + curr.chargeUSD, 0);
    const deposit = inspectingRental.depositAmountUSD;

    let refund = 0;
    let pending = 0;

    if (totalDamage <= deposit) {
      refund = deposit - totalDamage;
      pending = 0;
    } else {
      refund = 0;
      pending = totalDamage - deposit;
    }

    const updatedRental: RentalInspection = {
      ...inspectingRental,
      status: damagesList.length > 0 ? 'Devuelto con Daños' : 'Devuelto Conforme',
      actualReturnDate: new Date().toISOString().slice(0, 10),
      damages: damagesList,
      totalDamageChargeUSD: totalDamage,
      depositRefundUSD: refund,
      pendingChargeUSD: pending,
      inspectionNotes: inspectionNotes.trim() || (damagesList.length > 0 ? 'Inspeccionado con novedades.' : 'Devuelto en perfecto estado de conservación e higiene.'),
      inspectedAt: new Date().toISOString(),
      inspectedBy: 'Lcdo. Josmar Puerta',
    };

    onUpdateRental(updatedRental);
    setInspectingRental(null);
    setViewingActa(updatedRental);
  };

  const sendWhatsAppNotification = (rental: RentalInspection) => {
    const phone = rental.clientPhone.replace(/[^0-9]/g, '');
    if (!phone) return;

    const isConforme = rental.status === 'Devuelto Conforme';
    let text = '';

    if (isConforme) {
      text = `🎈 *BALLÓN DULCES KLHOE* - Acta de Retiro y Devolución de Mobiliario\n\n` +
        `Estimado(a) *${rental.clientName}*,\n` +
        `Confirmamos que el retiro e inspección del mobiliario para su evento (Pedido / Ref: *${rental.documentNumber}*) ha sido completado con total éxito en *PERFECTO ESTADO*.\n\n` +
        `✅ *Depósito de Garantía:* Se libera formalmente el reintegro de *$${rental.depositRefundUSD.toFixed(2)} USD* (≈ Bs. ${(rental.depositRefundUSD * currentRate).toFixed(2)}).\n\n` +
        `🌟 *¡Muchísimas gracias por preferir nuestro servicio!* En Ballón Dulces Klhoe valoramos profundamente su preferencia y confianza para ser parte de sus momentos más especiales. ¡Ha sido un inmenso placer atenderle y esperamos seguir acompañándole en sus próximas celebraciones!\n\n` +
        `_Lcdo. Josmar Puerta - Ballón Dulces Klhoe_`;
    } else {
      text = `🎈 *BALLÓN DULCES KLHOE* - Notificación de Inspección de Alquiler\n\n` +
        `Estimado(a) *${rental.clientName}*,\n` +
        `Se ha realizado la inspección técnica de retiro para su evento (Pedido / Ref: *${rental.documentNumber}*):\n\n` +
        `⚠️ *Novedades registradas:* ${rental.damages.map(d => `\n- ${d.itemName} (${d.damageType}): $${d.chargeUSD.toFixed(2)}`).join('')}\n\n` +
        `💰 *Total daños/reposición:* $${rental.totalDamageChargeUSD.toFixed(2)}\n` +
        `💵 *Garantía inicial:* $${rental.depositAmountUSD.toFixed(2)}\n` +
        (rental.pendingChargeUSD > 0
          ? `❗ *Saldo pendiente por pagar (24h):* $${rental.pendingChargeUSD.toFixed(2)} (Bs. ${(rental.pendingChargeUSD * currentRate).toFixed(2)})\n`
          : `✅ *Reintegro de garantía restante:* $${rental.depositRefundUSD.toFixed(2)} (Bs. ${(rental.depositRefundUSD * currentRate).toFixed(2)})\n`) +
        `\n🌟 *¡Muchas gracias por preferir nuestro servicio!* En Ballón Dulces Klhoe agradecemos sinceramente su preferencia y confianza. Para cualquier consulta quedamos a su completa orden.\n\n` +
        `_Lcdo. Josmar Puerta - Ballón Dulces Klhoe_`;
    }

    const url = `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  // Generador de mensaje para la persona encargada de la recolección del material
  const generateDriverReminderMessage = (
    rental: RentalInspection, 
    driver: string, 
    time: string = '10:00 PM', 
    notes: string = ''
  ) => {
    let msg = `🚚 *RECORDATORIO DE RECOLECCIÓN Y DESMONTAJE DE MOBILIARIO* 🚚\n`;
    msg += `🎈 *BALLÓN DULCES KLHOE*\n`;
    msg += `-------------------------------------------------\n`;
    msg += `👤 *ENCARGADO / CHOFER:* ${driver}\n`;
    msg += `📄 *Nº DE PEDIDO / FACTURA:* ${rental.documentNumber}\n`;
    msg += `📅 *FECHA DE RECOLECCIÓN:* ${rental.expectedReturnDate || rental.dispatchDate}\n`;
    if (time) {
      msg += `⏰ *HORA PREVISTA DE RECOLECCIÓN:* ${time}\n`;
    }
    msg += `🗓️ *FECHA DEL EVENTO:* ${rental.dispatchDate}\n`;
    msg += `🏢 *CLIENTE:* ${rental.clientName}\n`;
    msg += `📞 *TELÉFONO CLIENTE:* ${rental.clientPhone || 'N/A'}\n`;
    msg += `📍 *DIRECCIÓN DE RECOLECCIÓN:* ${rental.eventLocation}\n`;
    msg += `-------------------------------------------------\n`;
    msg += `📦 *DETALLE DE MATERIAL A RECOLECTAR (${rental.itemsDispatched.reduce((acc, it) => acc + it.quantity, 0)} piezas en total):*\n`;
    rental.itemsDispatched.forEach((item, index) => {
      msg += `  ${index + 1}. [   ] ${item.name} ➔ *${item.quantity} unidades*\n`;
    });
    msg += `-------------------------------------------------\n`;
    if (notes) {
      msg += `📝 *OBSERVACIONES:* ${notes}\n`;
      msg += `-------------------------------------------------\n`;
    }
    msg += `⚠️ *CHECKLIST OBLIGATORIO EN SITIO:*\n`;
    msg += `1. Contar todas las piezas físicamente antes de subirlas al transporte.\n`;
    msg += `2. Verificar ausencia de roturas, quemaduras de cera o manchas graves.\n`;
    msg += `3. Solicitar visto bueno del cliente o encargado antes de retirarse.\n`;
    msg += `-------------------------------------------------\n`;
    msg += `_Coordinación de Logística: Lcdo. Josmar Puerta - Ballón Dulces Klhoe_`;
    return msg;
  };

  const sendDriverReminderWhatsApp = (rental: RentalInspection) => {
    const text = generateDriverReminderMessage(rental, driverName, pickupTime, pickupNotes);
    const cleanPhone = driverPhone.replace(/[^0-9]/g, '');
    const url = cleanPhone
      ? `https://wa.me/${cleanPhone.startsWith('58') ? cleanPhone : cleanPhone.startsWith('0') ? `58${cleanPhone.slice(1)}` : `58${cleanPhone}`}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const handleCopyDriverReminder = (rental: RentalInspection) => {
    const text = generateDriverReminderMessage(rental, driverName, pickupTime, pickupNotes);
    navigator.clipboard.writeText(text);
    setCopiedReminder(true);
    setTimeout(() => setCopiedReminder(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Cabecera y Título */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white/80 backdrop-blur-md p-6 rounded-3xl border border-stone-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-red-100 text-red-600">
              <ArrowLeftRight className="w-5 h-5" />
            </span>
            <h2 className="text-xl md:text-2xl font-bold font-script text-fuchsia-950">
              Control de Alquileres, Entregas y Devoluciones
            </h2>
          </div>
          <p className="text-xs text-stone-600 mt-1">
            Supervisión de mobiliario en calle, registro de actas de inspección, control de daños y liquidación de garantías.
          </p>
        </div>

        <button
          onClick={() => setShowNewRentalModal(true)}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-2xl text-xs font-semibold shadow-sm transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Nuevo Despacho</span>
        </button>
      </div>

      {/* Semáforo de Mobiliario en Calle */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* En Calle */}
        <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800">
              Mobiliario en Calle
            </span>
            <h3 className="text-2xl font-bold text-amber-950 mt-0.5">
              {totalPiecesInStreet} <span className="text-xs font-normal text-amber-700">piezas</span>
            </h3>
            <p className="text-[10px] text-amber-700 mt-0.5">
              En {activeRentals.length} eventos activos
            </p>
          </div>
          <div className="p-3 bg-amber-200/60 rounded-2xl text-amber-800">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Garantías Retenidas */}
        <div className="p-4 bg-fuchsia-50/80 border border-fuchsia-200 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-fuchsia-800">
              Garantías en Custodia
            </span>
            <h3 className="text-2xl font-bold text-fuchsia-950 mt-0.5">
              ${totalDepositHeldUSD.toFixed(2)}
            </h3>
            <p className="text-[10px] text-fuchsia-700 mt-0.5">
              Bs. {(totalDepositHeldUSD * currentRate).toLocaleString('es-VE', { maximumFractionDigits: 2 })}
            </p>
          </div>
          <div className="p-3 bg-fuchsia-200/60 rounded-2xl text-fuchsia-800">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>

        {/* Devueltos Conformes */}
        <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              Devueltos Conformes
            </span>
            <h3 className="text-2xl font-bold text-emerald-950 mt-0.5">
              {rentals.filter((r) => r.status === 'Devuelto Conforme').length}
            </h3>
            <p className="text-[10px] text-emerald-700 mt-0.5">
              Sin roturas ni novedades
            </p>
          </div>
          <div className="p-3 bg-emerald-200/60 rounded-2xl text-emerald-800">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        {/* Novedades / Daños */}
        <div className="p-4 bg-red-50/80 border border-red-200 rounded-2xl flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-red-800">
              Con Daños / Cargos
            </span>
            <h3 className="text-2xl font-bold text-red-950 mt-0.5">
              {rentals.filter((r) => r.status === 'Devuelto con Daños').length}
            </h3>
            <p className="text-[10px] text-red-700 mt-0.5">
              Deducidos de garantía
            </p>
          </div>
          <div className="p-3 bg-red-200/60 rounded-2xl text-red-800">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Barra de Filtros y Búsqueda */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-col md:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'all'
                ? 'bg-fuchsia-950 text-white'
                : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
            }`}
          >
            Todos ({rentals.length})
          </button>
          <button
            onClick={() => setFilterStatus('calle')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'calle'
                ? 'bg-amber-600 text-white'
                : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
            }`}
          >
            En Calle ({activeRentals.length})
          </button>
          <button
            onClick={() => setFilterStatus('conforme')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'conforme'
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
            }`}
          >
            Devueltos Conformes
          </button>
          <button
            onClick={() => setFilterStatus('danos')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
              filterStatus === 'danos'
                ? 'bg-red-600 text-white'
                : 'bg-red-50 text-red-800 hover:bg-red-100 border border-red-200'
            }`}
          >
            Con Daños
          </button>
        </div>

        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por cliente, documento o ítem..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-500"
          />
        </div>
      </div>

      {/* Lista de Registros de Alquiler */}
      <div className="space-y-3">
        {filteredRentals.length === 0 ? (
          <div className="bg-white p-8 rounded-2xl border border-stone-200 text-center text-stone-500 text-sm">
            No se encontraron registros de alquiler con los filtros aplicados.
          </div>
        ) : (
          filteredRentals.map((rental) => {
            const isCalle = rental.status === 'En Evento (Calle)';
            const isConforme = rental.status === 'Devuelto Conforme';
            const isDanos = rental.status === 'Devuelto con Daños';

            return (
              <div
                key={rental.id}
                className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 shadow-xs hover:border-fuchsia-300 transition-all flex flex-col lg:flex-row lg:items-center justify-between gap-4"
              >
                {/* Info Principal */}
                <div className="space-y-1.5 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                      {rental.documentNumber}
                    </span>
                    <h4 className="font-bold text-sm text-stone-900">
                      {rental.clientName}
                    </h4>
                    {rental.clientCedulaRif && (
                      <span className="text-[10px] text-stone-500 font-mono">
                        ({rental.clientCedulaRif})
                      </span>
                    )}

                    {/* Status Badge */}
                    <span
                      className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border ${
                        isCalle
                          ? 'bg-amber-50 text-amber-800 border-amber-200'
                          : isConforme
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-red-50 text-red-800 border-red-200'
                      }`}
                    >
                      {rental.status}
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-stone-600">
                    <span className="flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5 text-stone-400" />
                      {rental.eventLocation}
                    </span>
                    <span className="flex items-center gap-1 font-mono">
                      <Calendar className="w-3.5 h-3.5 text-stone-400" />
                      Despacho: {rental.dispatchDate} • Retorno: {rental.expectedReturnDate}
                    </span>
                    <span className="flex items-center gap-1 font-mono text-stone-700">
                      <DollarSign className="w-3.5 h-3.5 text-stone-400" />
                      Garantía: ${rental.depositAmountUSD.toFixed(2)}
                    </span>
                  </div>

                  {/* Resumen de Artículos */}
                  <div className="text-xs bg-stone-50 p-2 rounded-xl border border-stone-150 flex flex-wrap gap-2 text-stone-700">
                    <strong className="text-stone-900">Mobiliario:</strong>
                    {rental.itemsDispatched.map((it, idx) => (
                      <span key={idx} className="bg-white px-2 py-0.5 rounded border border-stone-200 text-[11px]">
                        {it.name} <strong className="text-fuchsia-950 font-mono">x{it.quantity}</strong>
                      </span>
                    ))}
                  </div>

                  {/* Si tiene daños */}
                  {rental.damages.length > 0 && (
                    <div className="p-2 bg-red-50/60 rounded-xl border border-red-200 text-xs text-red-800">
                      <strong>Novedades registradas: </strong>
                      {rental.damages.map((d, i) => (
                        <span key={i} className="mr-2">
                          • {d.itemName} ({d.damageType}: ${d.chargeUSD.toFixed(2)})
                        </span>
                      ))}
                      <div className="mt-1 font-bold text-[11px]">
                        {rental.pendingChargeUSD > 0
                          ? `Pendiente de cobro extra: $${rental.pendingChargeUSD.toFixed(2)}`
                          : `Reintegro final de garantía: $${rental.depositRefundUSD.toFixed(2)}`}
                      </div>
                    </div>
                  )}
                </div>

                {/* Acciones */}
                <div className="flex flex-wrap items-center gap-2 shrink-0 pt-2 lg:pt-0 border-t lg:border-t-0 border-stone-100">
                  {/* Botón Recordatorio Chofer / Recolección */}
                  <button
                    onClick={() => {
                      setReminderRental(rental);
                      setCopiedReminder(false);
                    }}
                    title="Enviar Recordatorio de Recolección al Chofer / Encargado"
                    className="px-3 py-2 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
                  >
                    <Truck className="w-4 h-4 text-amber-700" />
                    <span>Recordatorio Recolección</span>
                  </button>

                  {isCalle ? (
                    <button
                      onClick={() => handleOpenInspection(rental)}
                      className="px-3.5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      <span>Registrar Devolución</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => setViewingActa(rental)}
                      className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-semibold flex items-center gap-1.5 cursor-pointer transition-colors"
                    >
                      <FileText className="w-4 h-4 text-stone-600" />
                      <span>Ver Acta</span>
                    </button>
                  )}

                  {rental.clientPhone && (
                    <button
                      onClick={() => sendWhatsAppNotification(rental)}
                      title="Enviar estado por WhatsApp"
                      className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded-xl cursor-pointer transition-colors"
                    >
                      <MessageCircle className="w-4 h-4" />
                    </button>
                  )}

                  <button
                    onClick={() => {
                      if (confirm('¿Eliminar este registro de alquiler?')) {
                        onDeleteRental(rental.id);
                      }
                    }}
                    title="Eliminar registro"
                    className="p-2 bg-stone-50 hover:bg-red-50 text-stone-400 hover:text-red-600 rounded-xl cursor-pointer transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* MODAL: REGISTRAR NUEVO DESPACHO */}
      {showNewRentalModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="text-lg font-bold font-script text-fuchsia-950">
                Nuevo Despacho de Mobiliario y Alquiler
              </h3>
              <button
                onClick={() => setShowNewRentalModal(false)}
                className="p-1 rounded-full text-stone-400 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveNewRental} className="space-y-4 mt-4">
              {/* Opción de importar desde factura existente */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Vincular a Factura / Nota Existente (Opcional):
                </label>
                <select
                  value={selectedInvoiceId}
                  onChange={(e) => handleSelectInvoice(e.target.value)}
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-500"
                >
                  <option value="">-- Sin vincular / Despacho manual --</option>
                  {invoices.map((inv) => (
                    <option key={inv.id} value={inv.id}>
                      {inv.type} Nº {inv.documentNumber} - {inv.clientName} (${inv.totalUSD.toFixed(2)})
                    </option>
                  ))}
                </select>
              </div>

              {/* Selector de Cliente si es manual */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Cliente Arrendatario:
                </label>
                <select
                  value={selectedClientId}
                  onChange={(e) => {
                    setSelectedClientId(e.target.value);
                    const cli = clients.find((c) => c.id === e.target.value);
                    if (cli) setEventLocation(cli.address);
                  }}
                  required
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-500"
                >
                  <option value="">Seleccione un cliente...</option>
                  {clients.map((cli) => (
                    <option key={cli.id} value={cli.id}>
                      {cli.name} {cli.cedulaRif ? `(${cli.cedulaRif})` : ''} - {cli.phone}
                    </option>
                  ))}
                </select>
              </div>

              {/* Locación */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Lugar del Evento / Entrega:
                </label>
                <input
                  type="text"
                  value={eventLocation}
                  onChange={(e) => setEventLocation(e.target.value)}
                  required
                  placeholder="Dirección del salón, club o casa..."
                  className="w-full text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-red-500"
                />
              </div>

              {/* Fechas */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Fecha de Entrega / Despacho:
                  </label>
                  <input
                    type="date"
                    value={dispatchDate}
                    onChange={(e) => setDispatchDate(e.target.value)}
                    required
                    className="w-full text-xs p-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Fecha Pactada de Retiro:
                  </label>
                  <input
                    type="date"
                    value={expectedReturnDate}
                    onChange={(e) => setExpectedReturnDate(e.target.value)}
                    required
                    className="w-full text-xs p-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                </div>
              </div>

              {/* Depósito en Garantía */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Depósito de Garantía Estipulado ($ USD):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="0"
                    step="5"
                    value={depositUSD}
                    onChange={(e) => setDepositUSD(Number(e.target.value))}
                    className="w-36 text-xs p-2.5 bg-stone-50 border border-stone-200 rounded-xl font-bold"
                  />
                  <span className="text-xs text-stone-500 font-mono">
                    ≈ Bs. {(depositUSD * currentRate).toFixed(2)}
                  </span>
                </div>
              </div>

              {/* Artículos a despachar */}
              <div className="border-t border-stone-200 pt-3">
                <label className="block text-xs font-bold text-stone-700 mb-2">
                  Artículos y Mobiliario a Despachar:
                </label>

                {/* Formulario rápido para agregar ítem */}
                <div className="flex items-center gap-2 mb-3">
                  <input
                    type="text"
                    placeholder="Ej. Sillas Tiffany, Mesa redonda, Backing..."
                    value={newItemName}
                    onChange={(e) => setNewItemName(e.target.value)}
                    className="flex-1 text-xs p-2 bg-stone-50 border border-stone-200 rounded-xl"
                  />
                  <input
                    type="number"
                    min="1"
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(Number(e.target.value))}
                    className="w-20 text-xs p-2 bg-stone-50 border border-stone-200 rounded-xl text-center font-bold"
                  />
                  <button
                    type="button"
                    onClick={handleAddItemToDispatch}
                    className="px-3 py-2 bg-fuchsia-950 text-white rounded-xl text-xs font-semibold cursor-pointer"
                  >
                    Agregar
                  </button>
                </div>

                {/* Lista */}
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {dispatchedItems.map((item, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between p-2 bg-stone-50 rounded-xl text-xs border border-stone-200"
                    >
                      <span className="text-stone-800 font-medium">
                        {item.name} <strong className="text-red-600 font-mono">x{item.quantity}</strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => handleRemoveItemFromDispatch(idx)}
                        className="text-stone-400 hover:text-red-600"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                  {dispatchedItems.length === 0 && (
                    <p className="text-xs text-stone-400 italic text-center py-2">
                      No hay artículos agregados todavía.
                    </p>
                  )}
                </div>
              </div>

              {/* Botones de acción */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setShowNewRentalModal(false)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-semibold shadow-xs"
                >
                  Guardar Despacho
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: REGISTRAR INSPECCIÓN Y RETIRO */}
      {inspectingRental && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div>
                <h3 className="text-lg font-bold font-script text-fuchsia-950">
                  Acta de Inspección de Retiro
                </h3>
                <p className="text-xs text-stone-500">
                  Evento: {inspectingRental.documentNumber} • {inspectingRental.clientName}
                </p>
              </div>
              <button
                onClick={() => setInspectingRental(null)}
                className="p-1 rounded-full text-stone-400 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 mt-4 text-xs">
              {/* Artículos que fueron entregados */}
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200">
                <span className="font-bold text-stone-700 block mb-1">
                  Mobiliario a Inspeccionar:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {inspectingRental.itemsDispatched.map((it, idx) => (
                    <span key={idx} className="bg-white px-2 py-0.5 rounded border border-stone-200">
                      {it.name} <strong className="text-fuchsia-950 font-mono">x{it.quantity}</strong>
                    </span>
                  ))}
                </div>
              </div>

              {/* Selector de Estado */}
              <div>
                <label className="block font-bold text-stone-700 mb-2">
                  Resultado de la Inspección Técnica:
                </label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => {
                      setInspectionResult('perfect');
                      setDamagesList([]);
                    }}
                    className={`p-3 rounded-2xl border text-left flex items-start gap-2 cursor-pointer transition-all ${
                      inspectionResult === 'perfect'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-950 ring-2 ring-emerald-200'
                        : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block text-xs">Todo Conforme</strong>
                      <span className="text-[11px] text-stone-500">
                        Sin roturas, sin manchas graves y limpio.
                      </span>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => setInspectionResult('damages')}
                    className={`p-3 rounded-2xl border text-left flex items-start gap-2 cursor-pointer transition-all ${
                      inspectionResult === 'damages'
                        ? 'bg-red-50 border-red-500 text-red-950 ring-2 ring-red-200'
                        : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                    }`}
                  >
                    <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="block text-xs">Reportar Novedades</strong>
                      <span className="text-[11px] text-stone-500">
                        Piezas rotas, cera, suciedad extrema o faltantes.
                      </span>
                    </div>
                  </button>
                </div>
              </div>

              {/* Si reporta daños */}
              {inspectionResult === 'damages' && (
                <div className="space-y-3 p-3.5 bg-red-50/50 rounded-2xl border border-red-200">
                  <h4 className="font-bold text-red-900 text-xs">
                    Agregar Artículo con Novedad / Daño:
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-0.5">Artículo Afectado:</label>
                      <input
                        type="text"
                        placeholder="Ej. Silla Tiffany rota..."
                        value={newDamageItemName}
                        onChange={(e) => setNewDamageItemName(e.target.value)}
                        className="w-full p-2 bg-white border border-stone-200 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-0.5">Tipo de Incidencia:</label>
                      <select
                        value={newDamageType}
                        onChange={(e) => setNewDamageType(e.target.value as any)}
                        className="w-full p-2 bg-white border border-stone-200 rounded-xl"
                      >
                        <option value="Rotura">Rotura / Fractura</option>
                        <option value="Extravío / Pérdida">Extravío / Pérdida</option>
                        <option value="Mancha Permanente">Mancha Permanente</option>
                        <option value="Cera de Velas / Quemadura">Cera de Velas / Quemadura</option>
                        <option value="Suciedad Extrema">Suciedad Extrema (Limpieza Profunda)</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-0.5">Costo de Reposición ($ USD):</label>
                      <input
                        type="number"
                        min="1"
                        value={newDamageCost}
                        onChange={(e) => setNewDamageCost(Number(e.target.value))}
                        className="w-full p-2 bg-white border border-stone-200 rounded-xl font-bold font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-stone-600 block mb-0.5">Nota / Observación:</label>
                      <input
                        type="text"
                        placeholder="Detalles del daño..."
                        value={newDamageNote}
                        onChange={(e) => setNewDamageNote(e.target.value)}
                        className="w-full p-2 bg-white border border-stone-200 rounded-xl"
                      />
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleAddDamageItem}
                    className="w-full py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold cursor-pointer"
                  >
                    + Registrar Este Daño en el Acta
                  </button>

                  {/* Lista de daños cargados */}
                  {damagesList.length > 0 && (
                    <div className="mt-2 space-y-1.5">
                      <strong className="block text-[11px] text-stone-700">Daños acumulados:</strong>
                      {damagesList.map((dmg) => (
                        <div
                          key={dmg.id}
                          className="flex items-center justify-between p-2 bg-white rounded-xl border border-red-200 text-xs"
                        >
                          <div>
                            <span className="font-bold text-stone-900">{dmg.itemName}</span>{' '}
                            <span className="text-stone-500">({dmg.damageType})</span>
                            <span className="font-mono text-red-600 font-bold block">
                              ${dmg.chargeUSD.toFixed(2)} (Bs. {(dmg.chargeUSD * currentRate).toFixed(2)})
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveDamage(dmg.id)}
                            className="text-stone-400 hover:text-red-600 p-1"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Resumen Financiero de la Garantía */}
              <div className="p-3 bg-stone-100 rounded-2xl border border-stone-200 space-y-1 text-xs">
                <div className="flex justify-between text-stone-600">
                  <span>Depósito de Garantía en Custodia:</span>
                  <span className="font-bold font-mono">${inspectingRental.depositAmountUSD.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-stone-600">
                  <span>Total Cargos por Daños / Reposición:</span>
                  <span className="font-bold font-mono text-red-600">
                    -${damagesList.reduce((acc, curr) => acc + curr.chargeUSD, 0).toFixed(2)}
                  </span>
                </div>
                <div className="border-t border-stone-300 pt-1.5 flex justify-between font-bold text-stone-900 text-sm">
                  {damagesList.reduce((acc, curr) => acc + curr.chargeUSD, 0) <= inspectingRental.depositAmountUSD ? (
                    <>
                      <span className="text-emerald-700">Monto a Reintegrar al Cliente:</span>
                      <span className="text-emerald-700 font-mono">
                        ${(inspectingRental.depositAmountUSD - damagesList.reduce((acc, curr) => acc + curr.chargeUSD, 0)).toFixed(2)}
                      </span>
                    </>
                  ) : (
                    <>
                      <span className="text-red-700">Saldo Extra a Pagar por el Cliente (24h):</span>
                      <span className="text-red-700 font-mono">
                        ${(damagesList.reduce((acc, curr) => acc + curr.chargeUSD, 0) - inspectingRental.depositAmountUSD).toFixed(2)}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* Notas del Inspector */}
              <div>
                <label className="block font-bold text-stone-700 mb-1">
                  Observaciones Generales de la Devolución:
                </label>
                <textarea
                  rows={2}
                  value={inspectionNotes}
                  onChange={(e) => setInspectionNotes(e.target.value)}
                  placeholder="Detalles sobre la entrega, embalaje o conversación con el cliente..."
                  className="w-full p-2.5 bg-stone-50 border border-stone-200 rounded-xl"
                />
              </div>

              {/* Acciones */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => setInspectingRental(null)}
                  className="px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={handleSaveInspection}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold shadow-xs"
                >
                  Finalizar Inspección & Generar Acta
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL / VISOR DEL ACTA DE INSPECCIÓN */}
      {viewingActa && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="text-lg font-bold font-script text-fuchsia-950">
                Acta Oficial de Devolución e Inspección
              </h3>
              <button
                onClick={() => setViewingActa(null)}
                className="p-1 rounded-full text-stone-400 hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-xs leading-relaxed text-stone-800">
              {/* Header Empresa */}
              <div className="text-center pb-2 border-b border-stone-200">
                <h4 className="text-base font-bold font-script text-fuchsia-950">
                  Ballón dulces Klhoe
                </h4>
                <p className="text-[10px] text-stone-500 font-mono">
                  RIF: V-26136645-0 • Lcdo. Josmar Puerta
                </p>
                <span className="inline-block mt-1 text-[10px] font-bold uppercase tracking-wider bg-stone-100 px-2 py-0.5 rounded border border-stone-300">
                  Acta Nº {viewingActa.id} • Ref: {viewingActa.documentNumber}
                </span>
              </div>

              {/* Ficha Cliente & Fechas */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-stone-500 block">Cliente:</span>
                  <strong>{viewingActa.clientName}</strong>
                  {viewingActa.clientCedulaRif && (
                    <span className="block text-stone-500">{viewingActa.clientCedulaRif}</span>
                  )}
                </div>
                <div>
                  <span className="text-stone-500 block">Fecha de Retiro:</span>
                  <strong>{viewingActa.actualReturnDate || viewingActa.expectedReturnDate}</strong>
                  <span className="block text-stone-500">{viewingActa.eventLocation}</span>
                </div>
              </div>

              {/* Estado */}
              <div className="p-3 rounded-xl border text-center font-bold text-xs" style={{
                backgroundColor: viewingActa.status === 'Devuelto Conforme' ? '#ecfdf5' : '#fef2f2',
                borderColor: viewingActa.status === 'Devuelto Conforme' ? '#a7f3d0' : '#fecaca',
                color: viewingActa.status === 'Devuelto Conforme' ? '#065f46' : '#991b1b',
              }}>
                Resultado: {viewingActa.status.toUpperCase()}
              </div>

              {/* Daños reportados si los hay */}
              {viewingActa.damages.length > 0 && (
                <div className="p-3 bg-red-50/60 rounded-xl border border-red-200 space-y-1">
                  <strong className="text-red-900 block font-bold text-[11px]">
                    Detalle de Daños / Cargos Aplicados:
                  </strong>
                  {viewingActa.damages.map((dmg, idx) => (
                    <div key={idx} className="flex justify-between text-[11px] text-stone-700">
                      <span>• {dmg.itemName} ({dmg.damageType})</span>
                      <span className="font-mono font-bold text-red-600">${dmg.chargeUSD.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              )}

              {/* Liquidación de Garantía */}
              <div className="p-3 bg-stone-100 rounded-xl border border-stone-200 space-y-1">
                <div className="flex justify-between">
                  <span>Garantía en Depósito:</span>
                  <span className="font-mono font-bold">${viewingActa.depositAmountUSD.toFixed(2)}</span>
                </div>
                {viewingActa.totalDamageChargeUSD > 0 && (
                  <div className="flex justify-between text-red-600">
                    <span>Deducción por Daños:</span>
                    <span className="font-mono font-bold">-${viewingActa.totalDamageChargeUSD.toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t border-stone-300 pt-1 flex justify-between font-bold text-stone-900 text-xs">
                  {viewingActa.pendingChargeUSD > 0 ? (
                    <>
                      <span className="text-red-700">Saldo Pendiente de Cobro:</span>
                      <span className="text-red-700 font-mono">${viewingActa.pendingChargeUSD.toFixed(2)}</span>
                    </>
                  ) : (
                    <>
                      <span className="text-emerald-700">Garantía Reintegrada al Cliente:</span>
                      <span className="text-emerald-700 font-mono">${viewingActa.depositRefundUSD.toFixed(2)}</span>
                    </>
                  )}
                </div>
              </div>

              {/* Firmas */}
              <div className="grid grid-cols-2 gap-4 text-center pt-4 border-t border-stone-200 text-[10px]">
                <div>
                  <div className="border-b border-stone-400 w-3/4 mx-auto mb-1 h-4" />
                  <strong>Firma del Cliente</strong>
                </div>
                <div>
                  <div className="border-b border-stone-400 w-3/4 mx-auto mb-1 h-4" />
                  <strong>Por Ballón Dulces Klhoe</strong>
                </div>
              </div>

              {/* Botones */}
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-200">
                <button
                  type="button"
                  onClick={() => sendWhatsAppNotification(viewingActa)}
                  className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Enviar por WhatsApp</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold flex items-center gap-1 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>Imprimir</span>
                </button>
                <button
                  type="button"
                  onClick={() => setViewingActa(null)}
                  className="px-3 py-2 bg-stone-900 text-white rounded-xl font-semibold cursor-pointer"
                >
                  Cerrar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: RECORDATORIO DE RECOLECCIÓN PARA EL ENCARGADO / CHOFER */}
      {reminderRental && (
        <div className="fixed inset-0 z-50 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn no-print">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-amber-200 max-h-[92vh] overflow-y-auto space-y-4">
            {/* Cabecera */}
            <div className="flex items-center justify-between pb-3 border-b border-amber-100">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0 border border-amber-200 shadow-xs">
                  <Truck className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-lg font-bold text-stone-900">
                      Recordatorio de Recolección de Mobiliario
                    </h3>
                    <span className="font-mono text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded border border-red-200">
                      Pedido #{reminderRental.documentNumber}
                    </span>
                  </div>
                  <p className="text-xs text-stone-500">
                    Notificación y orden de desmontaje para el chofer o equipo de logística
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setReminderRental(null)}
                className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-xl transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Ficha Resumen de la Recolección */}
            <div className="p-4 bg-gradient-to-r from-amber-50/80 via-white to-orange-50/80 rounded-2xl border border-amber-200/80 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900 block mb-0.5">
                  📅 Fecha Programada de Recolección:
                </span>
                <span className="text-base font-extrabold text-amber-900 font-mono block">
                  {reminderRental.expectedReturnDate || reminderRental.dispatchDate}
                </span>
                <span className="text-[10.5px] text-stone-500 block mt-0.5">
                  Evento realizado el: <strong className="font-mono">{reminderRental.dispatchDate}</strong>
                </span>
              </div>

              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block mb-0.5">
                  👤 Cliente y Contacto:
                </span>
                <strong className="text-stone-900 block text-sm">
                  {reminderRental.clientName}
                </strong>
                <span className="text-stone-600 font-mono text-[11px] block">
                  📞 Tel: {reminderRental.clientPhone || 'No registrado'}
                </span>
              </div>

              <div className="sm:col-span-2 pt-2 border-t border-amber-100">
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500 block mb-0.5">
                  📍 Dirección Exacta de Retiro:
                </span>
                <span className="text-stone-800 font-medium block bg-white/70 p-2 rounded-xl border border-amber-100">
                  {reminderRental.eventLocation}
                </span>
              </div>
            </div>

            {/* Checklist de Material a Recolectar */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold uppercase tracking-wider text-stone-700 flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Mobiliario a Recolectar ({reminderRental.itemsDispatched.reduce((acc, it) => acc + it.quantity, 0)} piezas):</span>
                </label>
                <span className="text-[10px] text-stone-400">Verificar todas antes de subir al transporte</span>
              </div>
              <div className="divide-y divide-stone-100 border border-stone-200 rounded-2xl bg-stone-50/50 max-h-40 overflow-y-auto">
                {reminderRental.itemsDispatched.map((it, idx) => (
                  <div key={idx} className="p-2.5 px-3 flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-md border border-stone-300 bg-white flex items-center justify-center text-stone-400 font-bold text-[10px]">
                        {idx + 1}
                      </span>
                      <span className="font-semibold text-stone-800">{it.name}</span>
                    </div>
                    <span className="font-mono font-bold text-fuchsia-950 bg-white px-2.5 py-0.5 rounded-lg border border-stone-200 text-xs">
                      {it.quantity} unidades
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Parámetros de Personalización del Recordatorio */}
            <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-3 text-xs">
              <span className="font-bold text-stone-800 block uppercase text-[11px] tracking-wide">
                Configurar Datos del Recordatorio
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <div>
                  <label className="block text-[11px] text-stone-600 font-semibold mb-1">
                    Chofer / Encargado:
                  </label>
                  <input
                    type="text"
                    value={driverName}
                    onChange={(e) => setDriverName(e.target.value)}
                    placeholder="Ej. Chofer Manuel Díaz"
                    className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-stone-600 font-semibold mb-1">
                    Teléfono WhatsApp Chofer:
                  </label>
                  <input
                    type="tel"
                    value={driverPhone}
                    onChange={(e) => setDriverPhone(e.target.value)}
                    placeholder="Ej. 04141234567"
                    className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-stone-600 font-semibold mb-1">
                    Hora Prevista:
                  </label>
                  <input
                    type="text"
                    value={pickupTime}
                    onChange={(e) => setPickupTime(e.target.value)}
                    placeholder="Ej. 10:00 PM"
                    className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs font-mono focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] text-stone-600 font-semibold mb-1">
                  Instrucciones o Notas Especiales para la Recolección:
                </label>
                <input
                  type="text"
                  value={pickupNotes}
                  onChange={(e) => setPickupNotes(e.target.value)}
                  placeholder="Ej. Entrada por estacionamiento lateral, llevar mantas para proteger los cilindros..."
                  className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-amber-500/30"
                />
              </div>
            </div>

            {/* Previsualización del Mensaje listo para WhatsApp */}
            <div>
              <span className="text-xs font-bold text-stone-700 uppercase tracking-wide block mb-1">
                Previsualización del Mensaje a Enviar al Encargado:
              </span>
              <pre className="p-3 bg-stone-100 rounded-xl border border-stone-200 text-[10.5px] text-stone-800 font-mono max-h-36 overflow-y-auto whitespace-pre-wrap leading-relaxed select-all">
                {generateDriverReminderMessage(reminderRental, driverName, pickupTime, pickupNotes)}
              </pre>
            </div>

            {/* Botones de Acción */}
            <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-2 border-t border-stone-200">
              <button
                type="button"
                onClick={() => setReminderRental(null)}
                className="w-full sm:w-auto px-4 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
              >
                Cerrar
              </button>

              <div className="w-full sm:w-auto flex flex-col sm:flex-row items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopyDriverReminder(reminderRental)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-1.5 px-3.5 py-2 bg-white border border-stone-300 hover:border-amber-400 text-stone-700 rounded-xl text-xs font-semibold cursor-pointer shadow-2xs transition-colors"
                >
                  {copiedReminder ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>¡Copiado al Portapapeles!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copiar Texto</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={() => sendDriverReminderWhatsApp(reminderRental)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs shadow-emerald-200 transition-all cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Enviar por WhatsApp al Chofer</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
