import React, { useState, useRef, useEffect } from 'react';
import { 
  Cloud, 
  Check, 
  AlertCircle, 
  RefreshCw, 
  ExternalLink, 
  FileSpreadsheet, 
  X, 
  ChevronDown,
  UserCheck
} from 'lucide-react';
import { User } from 'firebase/auth';

export type SyncState = 'synced' | 'pending' | 'syncing' | 'not_connected';

interface SyncStatusIndicatorProps {
  status: SyncState;
  lastSyncTime: string | null;
  lastSyncUrl: string | null;
  isSyncing: boolean;
  googleUser: User | null;
  onSyncNow: () => void;
  onGoogleSignIn: () => void;
  pendingCount?: number;
}

export const SyncStatusIndicator: React.FC<SyncStatusIndicatorProps> = ({
  status,
  lastSyncTime,
  lastSyncUrl,
  isSyncing,
  googleUser,
  onSyncNow,
  onGoogleSignIn,
  pendingCount = 0,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Cerrar popover al hacer clic fuera
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Formatear fecha y hora de la última sincronización en español
  const formatSyncTime = (isoString: string | null) => {
    if (!isoString) return 'Sin sincronizar aún';
    try {
      const date = new Date(isoString);
      return date.toLocaleString('es-VE', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: true,
      });
    } catch {
      return isoString;
    }
  };

  return (
    <div className="relative" ref={containerRef}>
      {/* Botón principal del indicador en el Header */}
      <button
        type="button"
        id="btn-sync-status-indicator"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-label="Estado de sincronización con Google Drive y Sheets"
        title={
          status === 'synced'
            ? 'Datos sincronizados con Google Drive/Sheets. Clic para ver detalles.'
            : status === 'syncing'
            ? 'Sincronizando con Google Drive/Sheets...'
            : 'Hay cambios pendientes de sincronizar con Google Drive/Sheets. Clic para sincronizar.'
        }
        className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all cursor-pointer shadow-xs select-none ${
          status === 'synced'
            ? 'bg-emerald-50/90 text-emerald-800 border-emerald-300 hover:bg-emerald-100 hover:border-emerald-400'
            : status === 'syncing'
            ? 'bg-sky-50 text-sky-800 border-sky-300 hover:bg-sky-100'
            : 'bg-amber-50/95 text-amber-900 border-amber-300 hover:bg-amber-100 hover:border-amber-400'
        }`}
      >
        {/* Icono de Nube con indicador visual */}
        <div className="relative flex items-center justify-center">
          {isSyncing ? (
            <RefreshCw className="w-4 h-4 text-sky-600 animate-spin" />
          ) : (
            <Cloud
              className={`w-4 h-4 ${
                status === 'synced'
                  ? 'text-emerald-600'
                  : 'text-amber-600'
              }`}
            />
          )}

          {/* Badge secundario en la nube */}
          {!isSyncing && (
            <span
              className={`absolute -top-1 -right-1 w-2 h-2 rounded-full border border-white ${
                status === 'synced'
                  ? 'bg-emerald-500'
                  : 'bg-amber-500 animate-pulse'
              }`}
            />
          )}
        </div>

        {/* Texto del estado */}
        <div className="flex items-center gap-1.5 text-left leading-none">
          <span className="hidden sm:inline font-medium text-[11px] opacity-80">Drive:</span>
          <span className="font-bold text-xs">
            {isSyncing
              ? 'Sincronizando...'
              : status === 'synced'
              ? 'Sincronizado'
              : 'Sinc. Pendiente'}
          </span>
        </div>

        {/* Chevron para denotar que es desplegable */}
        <ChevronDown
          className={`w-3.5 h-3.5 opacity-60 transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {/* Popover desplegable con detalles y acciones de sincronización */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-80 sm:w-92 bg-white rounded-2xl shadow-xl border border-stone-200/90 p-4 z-50 animate-fadeIn space-y-3.5 text-stone-800">
          {/* Cabecera del popover */}
          <div className="flex items-center justify-between pb-2.5 border-b border-stone-100">
            <div className="flex items-center gap-2">
              <div
                className={`p-1.5 rounded-lg ${
                  status === 'synced'
                    ? 'bg-emerald-100 text-emerald-700'
                    : status === 'syncing'
                    ? 'bg-sky-100 text-sky-700'
                    : 'bg-amber-100 text-amber-700'
                }`}
              >
                <Cloud className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-stone-900 leading-tight">
                  Google Drive & Sheets
                </h4>
                <p className="text-[10px] text-stone-500">Estado de Sincronización</p>
              </div>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Tarjeta de Estado Actual */}
          <div
            className={`p-3 rounded-xl border flex items-start gap-2.5 text-xs ${
              status === 'synced'
                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
                : status === 'syncing'
                ? 'bg-sky-50/70 border-sky-200 text-sky-900'
                : 'bg-amber-50/80 border-amber-200 text-amber-950'
            }`}
          >
            {status === 'synced' ? (
              <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            ) : status === 'syncing' ? (
              <RefreshCw className="w-4 h-4 text-sky-600 shrink-0 mt-0.5 animate-spin" />
            ) : (
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            )}
            <div className="space-y-0.5">
              <div className="font-bold">
                {status === 'synced'
                  ? 'Completamente sincronizado'
                  : status === 'syncing'
                  ? 'Subiendo datos a Google Sheets...'
                  : 'Sincronización pendiente'}
              </div>
              <p className="text-[11px] leading-relaxed opacity-90">
                {status === 'synced'
                  ? 'Todos los movimientos de facturación están respaldados en tu hoja de Google Sheets.'
                  : status === 'syncing'
                  ? 'Por favor espera unos momentos mientras se crea o actualiza la hoja.'
                  : 'Tienes registros o cambios recientes que aún no han sido subidos a tu Google Drive.'}
              </p>
            </div>
          </div>

          {/* Detalles Técnicos */}
          <div className="bg-stone-50 rounded-xl p-2.5 space-y-1.5 text-xs border border-stone-200/70">
            <div className="flex items-center justify-between">
              <span className="text-stone-500">Última sinc.:</span>
              <span className="font-semibold text-stone-800 font-mono text-[11px]">
                {formatSyncTime(lastSyncTime)}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-stone-500">Cuenta Google:</span>
              <span className="font-medium text-stone-800 truncate max-w-[160px] text-[11px]" title={googleUser?.email || ''}>
                {googleUser ? (
                  <span className="text-emerald-700 flex items-center gap-1">
                    <UserCheck className="w-3 h-3 inline" />
                    {googleUser.email || googleUser.displayName || 'Conectado'}
                  </span>
                ) : (
                  <span className="text-stone-400 italic">No conectada</span>
                )}
              </span>
            </div>

            {pendingCount > 0 && (
              <div className="flex items-center justify-between">
                <span className="text-stone-500">Registros locales:</span>
                <span className="font-semibold text-stone-800">{pendingCount} documentos</span>
              </div>
            )}
          </div>

          {/* Botones de acción */}
          <div className="space-y-2 pt-1">
            {!googleUser ? (
              <button
                onClick={() => {
                  onGoogleSignIn();
                  setIsOpen(false);
                }}
                className="w-full py-2 px-3 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors"
              >
                <Cloud className="w-3.5 h-3.5 text-fuchsia-400" />
                <span>Conectar con Google Workspace</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  onSyncNow();
                  setIsOpen(false);
                }}
                disabled={isSyncing}
                className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-all ${
                  status === 'pending'
                    ? 'bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-700 hover:to-fuchsia-700 text-white shadow-fuchsia-200'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                } disabled:opacity-50`}
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>
                  {isSyncing
                    ? 'Sincronizando...'
                    : status === 'pending'
                    ? 'Sincronizar con Google Sheets Ahora'
                    : 'Volver a Sincronizar'}
                </span>
              </button>
            )}

            {lastSyncUrl && (
              <a
                href={lastSyncUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full py-2 px-3 bg-white hover:bg-stone-50 text-stone-700 border border-stone-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
                <span>Abrir Hoja en Google Sheets</span>
                <ExternalLink className="w-3 h-3 text-stone-400 ml-0.5" />
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
