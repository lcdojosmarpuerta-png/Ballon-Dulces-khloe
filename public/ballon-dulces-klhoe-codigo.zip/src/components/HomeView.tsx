import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Users, 
  Boxes, 
  Receipt, 
  BarChart3, 
  ArrowRight, 
  CheckCircle2, 
  TrendingUp, 
  Layers,
  Clock,
  Share2,
  Copy,
  Check,
  Instagram,
  MessageCircle,
  ExternalLink,
  X,
  ArrowLeftRight,
  QrCode,
  ShoppingBag,
  Database
} from 'lucide-react';
import { ActiveTab } from './Sidebar';
import { Client, InventoryItem, InvoiceDocument } from '../types';

interface HomeViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  clientsCount: number;
  inventoryCount: number;
  invoicesCount: number;
  bcvRate: number | null;
  totalIncomeUSD: number;
  rentalsCount?: number;
}

export const HomeView: React.FC<HomeViewProps> = ({
  setActiveTab,
  clientsCount,
  inventoryCount,
  invoicesCount,
  bcvRate,
  totalIncomeUSD,
}) => {
  // Indicador de Fecha y Hora en tiempo real
  const [currentDateTime, setCurrentDateTime] = useState<Date>(new Date());
  const [showSocialModal, setShowSocialModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formattedDate = currentDateTime.toLocaleDateString('es-VE', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const formattedTime = currentDateTime.toLocaleTimeString('es-VE', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true,
  });

  const socialLinks = [
    {
      name: 'Instagram',
      handle: '@ballondulcesklhoe',
      url: 'https://instagram.com/ballondulcesklhoe',
      color: 'bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500 text-white',
      icon: Instagram,
      description: 'Fotos de decoraciones, arreglos y eventos'
    },
    {
      name: 'WhatsApp Oficial',
      handle: '+58 414-1234567',
      url: 'https://wa.me/584141234567?text=Hola%20Ballon%20Dulces%20Klhoe!%20Deseo%20informacion%20sobre%20sus%20servicios%20para%20eventos',
      color: 'bg-emerald-500 text-white',
      icon: MessageCircle,
      description: 'Atención personalizada y reservas'
    },
    {
      name: 'TikTok',
      handle: '@ballondulcesklhoe',
      url: 'https://tiktok.com/@ballondulcesklhoe',
      color: 'bg-stone-900 text-white',
      icon: Sparkles,
      description: 'Videos de montajes y fiestas en vivo'
    }
  ];

  const handleCopyAllSocials = () => {
    const shareText = `🎈 *Ballón dulces Klhoe* - Detalles que marcan la diferencia en tu fiesta ✨\n\n📸 Instagram: https://instagram.com/ballondulcesklhoe\n📲 WhatsApp: https://wa.me/584141234567\n🎵 TikTok: https://tiktok.com/@ballondulcesklhoe\n\n¡Síguenos y planifica tu próximo evento con nosotros!`;
    navigator.clipboard.writeText(shareText);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-6xl mx-auto">
      {/* Indicador de Fecha y Hora en Vivo */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white/90 backdrop-blur-md px-5 py-3 rounded-2xl border border-fuchsia-100 shadow-xs">
        <div className="flex items-center gap-2.5 text-stone-700">
          <div className="p-2 rounded-xl bg-red-50 text-red-600">
            <Clock className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <span className="text-xs font-semibold capitalize block text-stone-800">
              {formattedDate}
            </span>
            <span className="text-[11px] text-fuchsia-700 font-mono font-bold">
              Hora local: {formattedTime}
            </span>
          </div>
        </div>

        <button
          onClick={() => setShowSocialModal(true)}
          id="btn-share-social-home"
          className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-700 hover:to-fuchsia-700 text-white rounded-xl text-xs font-semibold shadow-xs shadow-fuchsia-200 transition-all cursor-pointer"
          title="Compartir redes sociales de Ballón Dulces Klhoe"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>Compartir Redes Sociales</span>
        </button>
      </div>

      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-red-600 via-rose-600 to-fuchsia-600 text-white p-8 md:p-12 shadow-xl shadow-fuchsia-200/50">
        {/* Abstract floral/linear accents */}
        <div className="absolute -top-12 -right-12 w-64 h-64 rounded-full bg-white/15 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-12 -left-12 w-64 h-64 rounded-full bg-fuchsia-900/30 blur-2xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/20 backdrop-blur-md text-xs font-semibold uppercase tracking-wider mb-4 border border-white/30 text-white">
            <Sparkles className="w-4 h-4 text-amber-200" />
            <span>Sistema Exclusivo para Eventos</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-script tracking-wide text-white drop-shadow-sm mb-3">
            Ballón dulces Klhoe
          </h1>

          <p className="text-xl md:text-2xl font-light italic text-rose-100 mb-6 font-script">
            "Detalles que marcan la diferencia en tu fiesta"
          </p>

          <p className="text-sm md:text-base text-white/90 leading-relaxed mb-8 max-w-xl">
            Bienvenido al panel centralizado de control de fiestas y eventos. Administra tu cartera de clientes, controla el inventario de decoración y pasapalos, genera presupuestos y facturas en formato fiscal o notas de entrega con tasa oficial BCV.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setActiveTab('facturacion')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-red-600 hover:text-fuchsia-700 font-bold text-sm shadow-md hover:bg-fuchsia-50 transition-all cursor-pointer transform hover:-translate-y-0.5"
            >
              <Receipt className="w-4 h-4 text-red-600" />
              <span>Emitir Factura / Nota</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTab('inventario')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-fuchsia-800/60 hover:bg-fuchsia-800/80 text-white font-medium text-sm backdrop-blur-sm border border-white/30 transition-all cursor-pointer"
            >
              <Boxes className="w-4 h-4" />
              <span>Ver Inventario</span>
            </button>
            <button
              onClick={() => setShowSocialModal(true)}
              className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-white/15 hover:bg-white/25 text-white font-medium text-sm backdrop-blur-sm border border-white/20 transition-all cursor-pointer"
            >
              <Share2 className="w-4 h-4" />
              <span>Redes Sociales</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white/95 backdrop-blur-xs p-5 rounded-2xl border border-fuchsia-100 shadow-xs hover:border-fuchsia-300 hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Clientes Registrados
            </span>
            <div className="p-2 rounded-xl bg-red-50 text-red-600">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-stone-800 font-mono">
            {clientsCount}
          </div>
          <p className="text-xs text-stone-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-red-500" />
            Base local disponible
          </p>
        </div>

        <div className="bg-white/95 backdrop-blur-xs p-5 rounded-2xl border border-fuchsia-100 shadow-xs hover:border-fuchsia-300 hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Artículos en Stock
            </span>
            <div className="p-2 rounded-xl bg-fuchsia-50 text-fuchsia-600">
              <Boxes className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-stone-800 font-mono">
            {inventoryCount}
          </div>
          <p className="text-xs text-stone-400 mt-1 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-fuchsia-500" />
            5 categorías activas
          </p>
        </div>

        <div className="bg-white/95 backdrop-blur-xs p-5 rounded-2xl border border-fuchsia-100 shadow-xs hover:border-fuchsia-300 hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Documentos Emitidos
            </span>
            <div className="p-2 rounded-xl bg-rose-50 text-rose-600">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-stone-800 font-mono">
            {invoicesCount}
          </div>
          <p className="text-xs text-stone-400 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-rose-500" />
            Facturas y notas
          </p>
        </div>

        <div className="bg-white/95 backdrop-blur-xs p-5 rounded-2xl border border-fuchsia-100 shadow-xs hover:border-fuchsia-300 hover:shadow-md transition-all">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Ingresos del Mes ($)
            </span>
            <div className="p-2 rounded-xl bg-red-50 text-red-600">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-bold text-red-700 font-mono">
            ${totalIncomeUSD.toFixed(2)}
          </div>
          <p className="text-xs text-stone-400 mt-1">
            ≈ {bcvRate ? `${(totalIncomeUSD * bcvRate).toLocaleString('es-VE', { maximumFractionDigits: 2 })} Bs` : 'Calculando Bs'}
          </p>
        </div>
      </div>

      {/* Module Shortcuts Grid */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold text-stone-800 flex items-center gap-2">
          <span>Módulos de Gestión</span>
          <span className="text-xs font-normal text-stone-400">
            Acceso directo a las 4 áreas principales
          </span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Módulo 1 */}
          <div
            onClick={() => setActiveTab('clientes')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-fuchsia-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-red-50 text-red-600 group-hover:bg-gradient-to-r group-hover:from-red-600 group-hover:to-rose-600 group-hover:text-white transition-all shadow-xs">
                <Users className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-red-600 transition-colors flex items-center justify-between">
                  <span>Módulo 1: Registro de Clientes</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Formulario de registro con captura de nombre, teléfono y dirección. Búsqueda instantánea en tiempo real y enlace directo a WhatsApp para atención al cliente.
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 2 */}
          <div
            onClick={() => setActiveTab('inventario')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-fuchsia-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-fuchsia-50 text-fuchsia-600 group-hover:bg-gradient-to-r group-hover:from-fuchsia-600 group-hover:to-pink-600 group-hover:text-white transition-all shadow-xs">
                <Boxes className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-fuchsia-600 transition-colors flex items-center justify-between">
                  <span>Módulo 2: Carga de Inventario</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Gestión de mobiliario, decoración, pasapalos, comestibles y sonido. Vista en tarjetas visuales de alta calidad con fotos, stock y precios.
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 3 */}
          <div
            onClick={() => setActiveTab('facturacion')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-fuchsia-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-gradient-to-tr from-red-50 to-fuchsia-50 text-red-600 group-hover:bg-gradient-to-r group-hover:from-red-600 group-hover:to-fuchsia-600 group-hover:text-white transition-all shadow-xs">
                <Receipt className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-red-600 transition-colors flex items-center justify-between">
                  <span>Módulo 3: Factura / Presupuesto</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Emisión de facturas fiscales (IVA 16%), presupuestos o notas de entrega sin impuestos. Conversión automática con tasa BCV e impresión a 1 sola página Letter Horizontal (Original y Copia).
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 4 */}
          <div
            onClick={() => setActiveTab('reportes')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-fuchsia-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-fuchsia-50 text-fuchsia-700 group-hover:bg-gradient-to-r group-hover:from-fuchsia-700 group-hover:to-red-600 group-hover:text-white transition-all shadow-xs">
                <BarChart3 className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-fuchsia-700 transition-colors flex items-center justify-between">
                  <span>Módulo 4: Reportes e Indicadores</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Filtro por rango de fechas, KPIs de facturas fiscales vs notas de entrega, exportación a Excel y sincronización directa en la nube con Google Sheets / Drive.
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 5 (Opción 1) */}
          <div
            onClick={() => setActiveTab('alquileres')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-amber-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-amber-50 text-amber-700 group-hover:bg-gradient-to-r group-hover:from-amber-600 group-hover:to-red-600 group-hover:text-white transition-all shadow-xs">
                <ArrowLeftRight className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-amber-700 transition-colors flex items-center justify-between">
                  <span>Módulo 5: Control Alquileres & Retiro</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Semáforo de mobiliario en calle, actas de inspección técnica al retorno, control de daños/roturas y liquidación automática de garantías.
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 6 (Opción 2) */}
          <div
            onClick={() => setActiveTab('mensajes')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-emerald-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-600 group-hover:bg-gradient-to-r group-hover:from-emerald-600 group-hover:to-teal-600 group-hover:text-white transition-all shadow-xs">
                <MessageCircle className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-emerald-700 transition-colors flex items-center justify-between">
                  <span>Módulo 6: WhatsApp & Cobranzas QR</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Plantillas automáticas para reservas, cobro de saldo 24h a tasa BCV, agradecimientos y generador de código QR para Pago Móvil.
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 7 (Opción 3) */}
          <div
            onClick={() => setActiveTab('catalogo')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-fuchsia-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-fuchsia-50 text-fuchsia-900 group-hover:bg-gradient-to-r group-hover:from-fuchsia-900 group-hover:to-pink-600 group-hover:text-white transition-all shadow-xs">
                <ShoppingBag className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-fuchsia-900 transition-colors flex items-center justify-between">
                  <span>Módulo 7: Catálogo & Cotizador Clientes</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Portafolio digital para compartir, armado de combo para fiestas con precios en USD y Bs, y envío directo a WhatsApp.
                </p>
              </div>
            </div>
          </div>

          {/* Módulo 8 (Opción 5) */}
          <div
            onClick={() => setActiveTab('respaldos')}
            className="p-6 rounded-2xl bg-white border border-fuchsia-100 hover:border-purple-300 shadow-xs hover:shadow-md transition-all cursor-pointer group"
          >
            <div className="flex items-start gap-4">
              <div className="p-3.5 rounded-2xl bg-purple-50 text-purple-700 group-hover:bg-gradient-to-r group-hover:from-purple-700 group-hover:to-fuchsia-700 group-hover:text-white transition-all shadow-xs">
                <Database className="w-6 h-6" />
              </div>
              <div className="flex-1">
                <h3 className="text-base font-bold text-stone-800 group-hover:text-purple-700 transition-colors flex items-center justify-between">
                  <span>Módulo 8: Copias de Seguridad & Respaldo</span>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                  Exportación de archivo .JSON y libro maestro Excel para guardar en tu equipo o restaurar datos de forma rápida y segura.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL: COMPARTIR REDES SOCIALES */}
      {showSocialModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/50 backdrop-blur-xs flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-fuchsia-100 space-y-5">
            {/* Cabecera */}
            <div className="flex items-center justify-between pb-3 border-b border-fuchsia-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-red-600 to-fuchsia-600 text-white flex items-center justify-center shadow-md shadow-fuchsia-200">
                  <Share2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">
                    Redes Sociales Oficiales
                  </h3>
                  <p className="text-xs text-stone-500">Ballón dulces Klhoe</p>
                </div>
              </div>
              <button
                onClick={() => setShowSocialModal(false)}
                className="p-1.5 text-stone-400 hover:text-stone-700 rounded-xl hover:bg-stone-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Lista de Enlaces */}
            <div className="space-y-3">
              {socialLinks.map((social) => {
                const IconComponent = social.icon;
                return (
                  <div
                    key={social.name}
                    className="p-3.5 rounded-2xl border border-stone-200 hover:border-fuchsia-300 hover:shadow-xs transition-all flex items-center justify-between gap-3 bg-stone-50/50 hover:bg-white"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`p-2.5 rounded-xl ${social.color} shrink-0`}>
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <div className="truncate">
                        <span className="font-bold text-stone-800 text-xs block">
                          {social.name}
                        </span>
                        <span className="text-[11px] text-fuchsia-800 font-medium block truncate">
                          {social.handle}
                        </span>
                        <span className="text-[10px] text-stone-400 block truncate">
                          {social.description}
                        </span>
                      </div>
                    </div>

                    <a
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-1.5 bg-white border border-stone-200 hover:border-fuchsia-400 text-stone-700 hover:text-fuchsia-700 rounded-xl text-xs font-semibold shadow-2xs transition-colors shrink-0"
                    >
                      <span>Abrir</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                );
              })}
            </div>

            {/* Botón Copiar Todos los Enlaces */}
            <div className="pt-2">
              <button
                onClick={handleCopyAllSocials}
                className="w-full py-2.5 px-4 bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-700 hover:to-fuchsia-700 text-white rounded-xl text-xs font-bold shadow-xs shadow-fuchsia-200 flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-300" />
                    <span>¡Enlaces Copiados al Portapapeles!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copiar Enlaces para Compartir</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
