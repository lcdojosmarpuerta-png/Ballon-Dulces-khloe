import React, { useState } from 'react';
import { Scissors, FileText, CheckCircle, ShieldCheck, Printer } from 'lucide-react';
import { DocumentType, InvoiceItem, InvoiceStatus } from '../types';
import { printInvoiceElement } from '../lib/printUtils';

export interface PrintableInvoiceData {
  documentNumber: string;
  type: DocumentType;
  status: InvoiceStatus;
  paymentMethod?: string;
  issueDate: string;
  eventDate?: string;
  clientName: string;
  clientCedulaRif?: string;
  clientPhone: string;
  clientAddress?: string;
  items: InvoiceItem[];
  subtotalUSD: number;
  ivaRate: number; // 0 or 0.16
  ivaUSD: number;
  totalUSD: number;
  bcvRate: number;
  totalBs: number;
  notes?: string;
}

interface PrintableInvoiceSheetProps {
  data: PrintableInvoiceData;
  id?: string;
  className?: string;
  onOpenPrintModal?: () => void;
}

export const PrintableInvoiceSheet: React.FC<PrintableInvoiceSheetProps> = ({
  data,
  id = 'printable-invoice-sheet',
  className = '',
  onOpenPrintModal,
}) => {
  const [activeViewSheet, setActiveViewSheet] = useState<'both' | 'front' | 'back'>('both');

  return (
    <div id={id} className={`space-y-4 ${className}`}>
      {/* Selector de Vista en Pantalla (No imprimible) */}
      <div className="no-print flex flex-wrap items-center justify-between gap-2 p-2 bg-stone-100 rounded-xl border border-stone-200 text-xs">
        <div className="flex items-center gap-2 text-stone-600 font-medium">
          <FileText className="w-4 h-4 text-fuchsia-600" />
          <span>Vista de Documento Emitido:</span>
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-stone-200">
            <button
              type="button"
              onClick={() => setActiveViewSheet('both')}
              className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                activeViewSheet === 'both'
                  ? 'bg-gradient-to-r from-red-600 to-fuchsia-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Ambas Hojas (Anverso y Reverso)
            </button>
            <button
              type="button"
              onClick={() => setActiveViewSheet('front')}
              className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                activeViewSheet === 'front'
                  ? 'bg-gradient-to-r from-red-600 to-fuchsia-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Hoja 1: Factura / Nota
            </button>
            <button
              type="button"
              onClick={() => setActiveViewSheet('back')}
              className={`px-3 py-1 rounded-md font-semibold transition-all cursor-pointer ${
                activeViewSheet === 'back'
                  ? 'bg-gradient-to-r from-red-600 to-fuchsia-600 text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Hoja 2: Términos (Reverso)
            </button>
          </div>

          <button
            type="button"
            onClick={() => {
              if (onOpenPrintModal) {
                onOpenPrintModal();
              } else {
                printInvoiceElement(id);
              }
            }}
            className="px-3 py-1.5 bg-gradient-to-r from-red-600 to-fuchsia-600 hover:from-red-700 hover:to-fuchsia-700 text-white rounded-lg font-bold flex items-center gap-1.5 shadow-xs cursor-pointer transition-all hover:scale-102"
            title="Imprimir o descargar PDF en formato Carta Horizontal"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Imprimir / Descargar PDF</span>
          </button>
        </div>
      </div>

      {/* PÁGINA 1: FACTURA / NOTA DE ENTREGA (ANVERSO) */}
      <div
        className={`print-page-front bg-white rounded-2xl border border-stone-300 p-3 sm:p-4 shadow-xs flex flex-col md:flex-row justify-between items-stretch gap-2 text-stone-900 overflow-hidden ${
          activeViewSheet === 'back' ? 'hidden print:hidden' : 'flex print:flex'
        }`}
        style={{ minHeight: '520px' }}
      >
        {/* LADO 1: ORIGINAL */}
        <div className="print-half flex-1 flex flex-col justify-between p-3 border border-stone-200 rounded-xl bg-white">
          <InvoiceHalfTemplate versionTag="ORIGINAL" data={data} />
        </div>

        {/* DIVISOR CENTRAL CON LÍNEA PUNTEADA Y TIJERA DE CORTE */}
        <div className="print-divider flex md:flex-col items-center justify-center py-2 md:py-0 px-2 text-stone-400 select-none">
          <div className="flex-1 w-full border-b md:border-b-0 md:border-l border-dashed border-stone-400" />
          <div className="p-1.5 my-1 rounded-full bg-stone-100 border border-stone-300 text-stone-500 flex items-center gap-1 shrink-0">
            <Scissors className="w-3.5 h-3.5 rotate-90 md:rotate-0" />
            <span className="text-[9px] font-bold uppercase tracking-wider hidden md:inline">
              Corte
            </span>
          </div>
          <div className="flex-1 w-full border-b md:border-b-0 md:border-l border-dashed border-stone-400" />
        </div>

        {/* LADO 2: COPIA */}
        <div className="print-half flex-1 flex flex-col justify-between p-3 border border-stone-200 rounded-xl bg-white">
          <InvoiceHalfTemplate versionTag="COPIA" data={data} />
        </div>
      </div>

      {/* PÁGINA 2: HOJA POSTERIOR / AL REVERSO (TÉRMINOS Y CONDICIONES DEL ALQUILER - ORIGINAL Y COPIA) */}
      <div
        className={`print-page-back bg-white rounded-2xl border border-stone-300 p-3 sm:p-4 shadow-xs flex flex-col md:flex-row justify-between items-stretch gap-2 text-stone-900 overflow-hidden ${
          activeViewSheet === 'front' ? 'hidden print:hidden' : 'flex print:flex'
        }`}
        style={{ minHeight: '520px' }}
      >
        <PrintableInvoiceReverseSheet data={data} />
      </div>
    </div>
  );
};

interface InvoiceHalfTemplateProps {
  versionTag: 'ORIGINAL' | 'COPIA';
  data: PrintableInvoiceData;
}

export const InvoiceHalfTemplate: React.FC<InvoiceHalfTemplateProps> = ({
  versionTag,
  data,
}) => {
  const {
    documentNumber,
    type,
    status,
    paymentMethod,
    issueDate,
    eventDate,
    clientName,
    clientCedulaRif,
    clientPhone,
    clientAddress,
    items,
    subtotalUSD,
    ivaRate,
    ivaUSD,
    totalUSD,
    bcvRate,
    totalBs,
    notes,
  } = data;

  const rate = bcvRate && bcvRate > 0 ? bcvRate : 36.5;

  return (
    <div className="w-full h-full flex flex-col justify-between text-[11px] leading-tight space-y-2">
      {/* Top Header */}
      <div>
        <div className="flex items-start justify-between border-b border-fuchsia-200 pb-1.5">
          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="text-sm font-bold font-script text-fuchsia-950 tracking-wide">
                Ballón dulces Klhoe
              </h4>
              <span
                className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded border ${
                  versionTag === 'ORIGINAL'
                    ? 'bg-red-50 text-red-700 border-red-300'
                    : 'bg-fuchsia-50 text-fuchsia-800 border-fuchsia-300'
                }`}
              >
                {versionTag}
              </span>
            </div>
            <p className="text-[9px] text-fuchsia-900/80 italic font-script">
              "Detalles que marcan la diferencia en tu fiesta"
            </p>
            <p className="text-[8.5px] text-stone-400">
              RIF: V-26136645-0 • Contacto: +58 414-1234567
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] font-bold uppercase tracking-wider block text-stone-700">
              {type}
            </span>
            <span className="text-xs font-mono font-extrabold text-red-600 block">
              {documentNumber}
            </span>
            <span className="text-[8px] font-semibold text-stone-500 block">
              F. Emisión: {issueDate}
            </span>
            {eventDate && (
              <span className="text-[8px] font-bold text-fuchsia-950 block">
                F. Evento: {eventDate}
              </span>
            )}
            <span
              className={`inline-block text-[8px] font-bold px-1 rounded uppercase mt-0.5 ${
                status === 'Pagada'
                  ? 'bg-emerald-100 text-emerald-800'
                  : status === 'Abonada'
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-red-100 text-red-800'
              }`}
            >
              {status}
            </span>
          </div>
        </div>

        {/* Client Info Banner */}
        <div className="mt-1.5 p-1.5 bg-stone-50 rounded border border-stone-200 text-[9.5px] grid grid-cols-2 gap-1">
          <div>
            <span className="font-semibold text-stone-600">Cliente: </span>
            <span className="font-bold text-stone-900">{clientName || 'Cliente sin registrar'}</span>
          </div>
          <div>
            <span className="font-semibold text-stone-600">C.I / RIF: </span>
            <span className="font-mono font-bold text-stone-800">{clientCedulaRif || 'N/A'}</span>
          </div>
          <div>
            <span className="font-semibold text-stone-600">Teléfono: </span>
            <span className="font-mono text-stone-800">{clientPhone || 'N/A'}</span>
          </div>
          <div>
            <span className="font-semibold text-stone-600">Pago: </span>
            <span className="font-bold text-red-600">{paymentMethod || 'Efectivo $'}</span>
          </div>
          <div className="col-span-2 truncate">
            <span className="font-semibold text-stone-600">Dirección: </span>
            <span className="text-stone-700">{clientAddress || 'Entrega en tienda / Por coordinar'}</span>
          </div>
        </div>
      </div>

      {/* Items Table */}
      <div className="flex-1 my-1 overflow-hidden">
        <table className="w-full text-left border-collapse text-[9px]">
          <thead>
            <tr className="border-b border-stone-300 text-stone-600 font-bold uppercase text-[8px] bg-stone-100/70">
              <th className="py-1 px-1">Descripción / Servicio</th>
              <th className="py-1 px-1 text-center w-10">Cant</th>
              <th className="py-1 px-1 text-right w-14">P.U ($)</th>
              <th className="py-1 px-1 text-right w-14">Total ($)</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-150">
            {items.length === 0 ? (
              <tr>
                <td colSpan={4} className="py-2 text-center text-stone-400 italic">
                  Sin ítems agregados
                </td>
              </tr>
            ) : (
              items.slice(0, 5).map((it) => (
                <tr key={it.id}>
                  <td className="py-0.8 px-1 text-stone-800 truncate max-w-[130px]">
                    {it.name}
                  </td>
                  <td className="py-0.8 px-1 text-center font-mono text-stone-600">
                    {it.quantity}
                  </td>
                  <td className="py-0.8 px-1 text-right font-mono text-stone-600">
                    ${it.unitPrice.toFixed(2)}
                  </td>
                  <td className="py-0.8 px-1 text-right font-mono font-bold text-stone-900">
                    ${it.total.toFixed(2)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Bottom Notes & Financial Breakdown */}
      <div className="border-t border-stone-200 pt-1">
        <div className="grid grid-cols-2 gap-2">
          {/* Notes & Bank Details */}
          <div className="text-[8px] text-stone-500 space-y-0.5">
            {notes && (
              <p className="line-clamp-2">
                <strong className="text-stone-700">Obs:</strong> {notes}
              </p>
            )}
            <p className="font-semibold text-stone-700">
              Método: <span className="text-red-700 font-bold">{paymentMethod || 'Efectivo $'}</span>
            </p>
            <p className="text-[7.5px] text-stone-500">
              Pagos: Pago Móvil / Zelle / Binance / Efectivo
            </p>
            <p className="text-[7.5px] text-stone-400">
              Sistema Elaborado por: Lcdo. Josmar Puerta
            </p>
          </div>

          {/* Totals Box */}
          <div className="text-[9px] space-y-0.5 text-right font-mono">
            <div className="flex justify-between">
              <span className="text-stone-500">Subtotal:</span>
              <span className="font-semibold text-stone-800">${subtotalUSD.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-stone-500">
                IVA ({type === 'Nota de Entrega' || ivaRate === 0 ? '0% Exento' : '16%'}):
              </span>
              <span className="font-semibold text-stone-800">${ivaUSD.toFixed(2)}</span>
            </div>
            <div className="flex justify-between border-t border-stone-200 pt-0.5 text-stone-900 font-bold">
              <span>Total USD:</span>
              <span className="text-red-600">${totalUSD.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-[8px] text-stone-500">
              <span>Tasa BCV:</span>
              <span>{rate.toFixed(2)} Bs/$</span>
            </div>
            <div className="flex justify-between text-[10px] font-extrabold text-stone-900 bg-fuchsia-50 px-1 rounded border border-fuchsia-200">
              <span>Total Bs:</span>
              <span>
                {totalBs.toLocaleString('es-VE', {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}{' '}
                Bs.
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Pie de Página de la Factura (Términos y Firmas Conformes exclusivamente al Reverso) */}
      <div className="border-t border-stone-200 pt-1.5 mt-1 text-[7px] text-stone-500 flex items-center justify-between">
        <span>* Comprobante emitido para alquiler y recepción de mobiliario</span>
        <span className="italic font-medium text-fuchsia-900/80">
          Términos, condiciones y firmas de conformidad al reverso →
        </span>
      </div>
    </div>
  );
};

{/* =========================================================================
    HOJA POSTERIOR (AL REVERSO): TÉRMINOS Y CONDICIONES (ORIGINAL Y COPIA)
   ========================================================================= */}
export const PrintableInvoiceReverseSheet: React.FC<{ data: PrintableInvoiceData }> = ({
  data,
}) => {
  return (
    <>
      {/* LADO 1: TÉRMINOS ORIGINAL */}
      <div className="print-half flex-1 flex flex-col justify-between p-2.5 sm:p-3 border border-stone-200 rounded-xl bg-white">
        <TermsHalfTemplate versionTag="ORIGINAL" data={data} />
      </div>

      {/* DIVISOR CENTRAL CON LÍNEA PUNTEADA Y TIJERA DE CORTE */}
      <div className="print-divider flex md:flex-col items-center justify-center py-2 md:py-0 px-2 text-stone-400 select-none">
        <div className="flex-1 w-full border-b md:border-b-0 md:border-l border-dashed border-stone-400" />
        <div className="p-1.5 my-1 rounded-full bg-stone-100 border border-stone-300 text-stone-500 flex items-center gap-1 shrink-0">
          <Scissors className="w-3.5 h-3.5 rotate-90 md:rotate-0" />
          <span className="text-[9px] font-bold uppercase tracking-wider hidden md:inline">
            Corte
          </span>
        </div>
        <div className="flex-1 w-full border-b md:border-b-0 md:border-l border-dashed border-stone-400" />
      </div>

      {/* LADO 2: TÉRMINOS COPIA */}
      <div className="print-half flex-1 flex flex-col justify-between p-2.5 sm:p-3 border border-stone-200 rounded-xl bg-white">
        <TermsHalfTemplate versionTag="COPIA" data={data} />
      </div>
    </>
  );
};

interface TermsHalfTemplateProps {
  versionTag: 'ORIGINAL' | 'COPIA';
  data: PrintableInvoiceData;
}

export const TermsHalfTemplate: React.FC<TermsHalfTemplateProps> = ({
  versionTag,
  data,
}) => {
  const {
    documentNumber,
    type,
    issueDate,
    clientName,
    clientCedulaRif,
    paymentMethod,
  } = data;

  return (
    <div className="w-full h-full flex flex-col justify-between text-[7.8px] leading-tight space-y-1 select-none">
      {/* Top Header */}
      <div className="border-b border-fuchsia-200 pb-1">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-1.5">
              <h4 className="text-xs font-bold font-script text-fuchsia-950 tracking-wide">
                Ballón dulces Klhoe
              </h4>
              <span
                className={`text-[7.5px] font-extrabold px-1.5 py-0.2 rounded border ${
                  versionTag === 'ORIGINAL'
                    ? 'bg-red-50 text-red-700 border-red-300'
                    : 'bg-fuchsia-50 text-fuchsia-800 border-fuchsia-300'
                }`}
              >
                {versionTag}
              </span>
            </div>
            <p className="text-[7.5px] text-fuchsia-900/80 italic font-script">
              "Detalles que marcan la diferencia en tu fiesta"
            </p>
          </div>

          <div className="text-right">
            <span className="text-[8px] font-mono font-bold text-red-600 block">
              {type} Nº {documentNumber}
            </span>
            <span className="text-[7px] text-stone-500 block">
              Fecha: {issueDate} • {paymentMethod || 'Efectivo $'}
            </span>
          </div>
        </div>

        <div className="mt-0.5 px-1 py-0.5 bg-fuchsia-50 rounded border border-fuchsia-200 flex items-center justify-between text-[7px]">
          <span className="font-bold text-fuchsia-950 uppercase tracking-wide">
            Términos y Condiciones Generales del Contrato de Alquiler
          </span>
          <span className="text-[6.5px] font-mono text-stone-500">
            RIF: V-26136645-0
          </span>
        </div>
      </div>

      {/* Mini Client Banner */}
      <div className="px-1.5 py-0.5 bg-stone-50 rounded border border-stone-200 text-[7.5px] grid grid-cols-2 gap-x-2">
        <div className="truncate">
          <span className="font-semibold text-stone-500">Cliente: </span>
          <strong className="text-stone-900">{clientName || 'Cliente sin registrar'}</strong>
        </div>
        <div className="text-right">
          <span className="font-semibold text-stone-500">C.I / RIF: </span>
          <strong className="font-mono text-stone-800">{clientCedulaRif || 'N/A'}</strong>
        </div>
      </div>

      {/* 5 Cláusulas Legales en Formato Riguroso */}
      <div className="flex-1 space-y-1 text-[7.2px] leading-tight text-stone-700">
        <div className="p-1 bg-stone-50/70 rounded border border-stone-200">
          <strong className="text-stone-900 text-[7.5px] block font-bold text-fuchsia-950">
            1. Objeto del Alquiler y Estado de Entrega:
          </strong>
          <p className="text-stone-600 text-justify">
            La empresa concede en arrendamiento temporal los artículos y mobiliario detallados en el anverso en óptimas condiciones de conservación, funcionamiento e higiene, destinados exclusivamente al evento indicado.
          </p>
        </div>

        <div className="p-1 bg-red-50/40 rounded border border-red-200">
          <div className="flex items-center gap-1 text-red-700 font-bold text-[7.5px]">
            <ShieldCheck className="w-2.5 h-2.5 text-red-600 shrink-0" />
            <span>2. Daños, Pérdidas y Limpieza (Cláusula Primordial):</span>
          </div>
          <p className="text-stone-700 text-justify mt-0.5">
            <strong>Responsabilidad:</strong> El arrendatario asume la responsabilidad y custodia total del mobiliario desde la entrega hasta su retiro por la agencia.
            <br />
            <strong>Reposición:</strong> Todo artículo roto, quemado, manchado permanentemente, mojado o extraviado será cobrado a su valor de reposición de mercado (deducible del depósito o cancelable en 24h).
            <br />
            <strong>Limpieza Extrema:</strong> Recargo por cera de velas, pintura, barro excesivo o suciedad profunda especializada.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-1">
          <div className="p-1 bg-stone-50/70 rounded border border-stone-200">
            <strong className="text-stone-900 text-[7.5px] block font-bold text-fuchsia-950">
              3. Depósito de Garantía:
            </strong>
            <p className="text-stone-600 text-justify">
              Depósito en garantía reintegrable tras la inspección técnica post-evento en condiciones óptimas.
            </p>
          </div>
          <div className="p-1 bg-stone-50/70 rounded border border-stone-200">
            <strong className="text-stone-900 text-[7.5px] block font-bold text-fuchsia-950">
              4. Logística y Horarios:
            </strong>
            <p className="text-stone-600 text-justify">
              El cliente garantiza acceso oportuno para entrega y desmontaje. Retrasos generarán recargos por espera.
            </p>
          </div>
        </div>

        <div className="p-1 bg-stone-50/70 rounded border border-stone-200">
          <strong className="text-stone-900 text-[7.5px] block font-bold text-fuchsia-950">
            5. Medios de Pago y Tasa Oficial BCV:
          </strong>
          <p className="text-stone-600 text-justify">
            Todo pago convenido en Bolívares se liquida según la Tasa Oficial del BCV. Medios: Pago Móvil, Binance (USDT), Transferencia, Zelle y Efectivo divisas en billetes íntegros.
          </p>
        </div>
      </div>

      {/* Recuadro de Firmas Conformes */}
      <div className="pt-0.5 border-t border-dashed border-stone-300">
        <div className="grid grid-cols-2 gap-3 text-center text-[7px] text-stone-600">
          <div>
            <div className="border-b border-stone-400 w-4/5 mx-auto mb-0.5 h-2.5" />
            <strong className="text-stone-900 block">Firma Conforme del Cliente</strong>
            <span className="text-[6.5px] text-stone-500 font-mono">
              C.I / RIF: {clientCedulaRif || '________________'}
            </span>
          </div>
          <div>
            <div className="border-b border-stone-400 w-4/5 mx-auto mb-0.5 h-2.5" />
            <strong className="text-stone-900 block">Por Ballón Dulces Klhoe</strong>
            <span className="text-[6.5px] text-stone-500">
              Lcdo. Josmar Puerta • RIF: V-26136645-0
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

