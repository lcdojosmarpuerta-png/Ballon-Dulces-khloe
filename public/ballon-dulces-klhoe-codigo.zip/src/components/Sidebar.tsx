import React from 'react';
import { 
  Home, 
  Users, 
  Boxes, 
  Receipt, 
  BarChart3, 
  Sparkles, 
  Calendar,
  LogOut,
  FolderHeart,
  ArrowLeftRight,
  MessageCircle,
  ShoppingBag,
  Database
} from 'lucide-react';
import { User } from 'firebase/auth';

export type ActiveTab = 
  | 'inicio' 
  | 'clientes' 
  | 'inventario' 
  | 'facturacion' 
  | 'alquileres' 
  | 'mensajes' 
  | 'catalogo' 
  | 'reportes' 
  | 'respaldos';

interface SidebarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  googleUser: User | null;
  onGoogleSignIn: () => void;
  onGoogleSignOut: () => void;
  isLoggingIn: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  googleUser,
  onGoogleSignIn,
  onGoogleSignOut,
  isLoggingIn,
}) => {
  const navItems = [
    {
      id: 'inicio' as ActiveTab,
      label: 'Inicio',
      description: 'Bienvenida y métricas',
      icon: Home,
    },
    {
      id: 'clientes' as ActiveTab,
      label: 'Registro de Clientes',
      description: 'Directorio y teléfonos',
      icon: Users,
    },
    {
      id: 'inventario' as ActiveTab,
      label: 'Carga de Inventario',
      description: 'Stock, precios y fotos',
      icon: Boxes,
    },
    {
      id: 'facturacion' as ActiveTab,
      label: 'Factura / Presupuesto',
      description: 'Emisión y cálculo BCV',
      icon: Receipt,
    },
    {
      id: 'alquileres' as ActiveTab,
      label: 'Control Alquileres & Retiro',
      description: 'Mobiliario en calle y actas',
      icon: ArrowLeftRight,
    },
    {
      id: 'mensajes' as ActiveTab,
      label: 'WhatsApp & QR Cobranzas',
      description: 'Plantillas y QR Pago Móvil',
      icon: MessageCircle,
    },
    {
      id: 'catalogo' as ActiveTab,
      label: 'Catálogo & Cotizador',
      description: 'Portafolio para clientes',
      icon: ShoppingBag,
    },
    {
      id: 'reportes' as ActiveTab,
      label: 'Reportes y Métricas',
      description: 'Excel y Google Sheets',
      icon: BarChart3,
    },
    {
      id: 'respaldos' as ActiveTab,
      label: 'Copias de Seguridad',
      description: 'Respaldo JSON y Excel',
      icon: Database,
    },
  ];

  return (
    <aside className="no-print w-64 md:w-72 bg-white/95 backdrop-blur-md border-r border-fuchsia-100 flex flex-col justify-between shrink-0 h-screen sticky top-0 shadow-xs z-40 select-none">
      {/* Brand Section */}
      <div className="flex-1 flex flex-col min-h-0">
        <div className="p-5 border-b border-fuchsia-50 flex items-center gap-3 shrink-0">
          <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-red-600 via-fuchsia-600 to-pink-500 flex items-center justify-center text-white shadow-md shadow-fuchsia-200 shrink-0">
            {/* Custom stylized balloon composition */}
            <svg viewBox="0 0 24 24" className="w-6 h-6 fill-white stroke-white" strokeWidth="1.5">
              <path d="M12 2C8.13 2 5 5.13 5 9c0 4.17 4.42 8.92 6.24 10.74.43.43 1.09.43 1.52 0C14.58 17.92 19 13.17 19 9c0-3.87-3.13-7-7-7z" fillOpacity="0.95" />
              <path d="M12 19.5v2.5M10.5 22h3" stroke="white" strokeLinecap="round" />
              <circle cx="15.5" cy="6.5" r="1.5" fill="#ffffff" />
            </svg>
          </div>
          <div>
            <h2 className="text-lg font-bold font-script text-fuchsia-900 tracking-wide leading-tight">
              Ballón dulces
            </h2>
            <span className="text-base font-bold font-script text-red-600 block -mt-1">
              Klhoe
            </span>
            <span className="text-[9px] tracking-wider uppercase font-semibold text-fuchsia-500">
              Event Management
            </span>
          </div>
        </div>

        {/* Navigation items scrollable */}
        <nav className="p-3 space-y-1 overflow-y-auto flex-1 pr-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-left transition-all cursor-pointer group ${
                  isActive
                    ? 'bg-gradient-to-r from-red-50/80 to-fuchsia-50 text-fuchsia-950 font-semibold shadow-xs border border-fuchsia-200/80'
                    : 'text-stone-600 hover:bg-fuchsia-50/50 hover:text-fuchsia-900'
                }`}
              >
                <div
                  className={`p-1.5 rounded-lg transition-all shrink-0 ${
                    isActive
                      ? 'bg-gradient-to-r from-red-600 to-fuchsia-600 text-white shadow-xs shadow-fuchsia-300'
                      : 'bg-stone-100 text-stone-500 group-hover:bg-fuchsia-100 group-hover:text-fuchsia-700'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold truncate leading-tight">{item.label}</div>
                  <div className="text-[10px] text-stone-400 group-hover:text-fuchsia-400/80 truncate font-normal leading-tight">
                    {item.description}
                  </div>
                </div>
                {isActive && (
                  <div className="w-1.5 h-4 rounded-full bg-gradient-to-b from-red-600 to-fuchsia-600 shrink-0" />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Bottom Integration & Creator Badge */}
      <div className="p-4 border-t border-fuchsia-100 space-y-3 bg-white/70">
        {/* Google Workspace Account Card */}
        <div className="p-3 rounded-xl bg-white border border-fuchsia-100 shadow-xs">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[10px] uppercase font-bold text-fuchsia-700 tracking-wider">
              Google Workspace
            </span>
            <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
              Drive & Sheets
            </span>
          </div>

          {googleUser ? (
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                {googleUser.photoURL ? (
                  <img
                    src={googleUser.photoURL}
                    alt={googleUser.displayName || 'Usuario'}
                    className="w-7 h-7 rounded-full border border-fuchsia-200"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-red-500 to-fuchsia-600 text-white flex items-center justify-center font-bold text-xs">
                    {googleUser.email?.[0].toUpperCase()}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-semibold text-stone-800 truncate">
                    {googleUser.displayName || 'Conectado'}
                  </p>
                  <p className="text-[10px] text-stone-400 truncate">
                    {googleUser.email}
                  </p>
                </div>
              </div>
              <button
                onClick={onGoogleSignOut}
                title="Cerrar sesión de Google"
                className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onGoogleSignIn}
              disabled={isLoggingIn}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 bg-white hover:bg-fuchsia-50/50 border border-fuchsia-200 rounded-lg text-xs font-medium text-stone-700 shadow-xs transition-colors cursor-pointer"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.34 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.34 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                />
              </svg>
              <span>{isLoggingIn ? 'Conectando...' : 'Vincular Google'}</span>
            </button>
          )}
        </div>

        {/* Autor oficial */}
        <div className="text-center pt-1">
          <p className="text-[11px] font-medium text-stone-500">
            Sistema Elaborado por:
          </p>
          <p className="text-xs font-bold text-red-600 hover:text-fuchsia-700 transition-colors">
            Lcdo. Josmar Puerta
          </p>
        </div>
      </div>
    </aside>
  );
};
