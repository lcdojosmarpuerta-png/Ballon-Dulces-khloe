import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import { 
  Database, 
  Download, 
  Upload, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  ShieldCheck, 
  Clock, 
  HardDrive, 
  FileJson, 
  Sparkles,
  RefreshCw
} from 'lucide-react';
import { 
  Client, 
  InventoryItem, 
  InvoiceDocument, 
  RentalInspection, 
  PagoMovilConfig, 
  BackupData 
} from '../types';

interface BackupsModuleProps {
  clients: Client[];
  inventory: InventoryItem[];
  invoices: InvoiceDocument[];
  rentals: RentalInspection[];
  pagoMovilConfig: PagoMovilConfig;
  bcvRate: number | null;
  onRestoreData: (backup: BackupData) => void;
}

export const BackupsModule: React.FC<BackupsModuleProps> = ({
  clients,
  inventory,
  invoices,
  rentals,
  pagoMovilConfig,
  bcvRate,
  onRestoreData,
}) => {
  const [lastBackupDate, setLastBackupDate] = useState<string | null>(() => {
    return localStorage.getItem('bdk_last_local_backup_date');
  });

  const [importPreview, setImportPreview] = useState<BackupData | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const [importSuccess, setImportSuccess] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  const currentRate = bcvRate || 36.5;

  // Exportar archivo JSON completo
  const handleExportJSON = () => {
    const backup: BackupData = {
      version: '1.0.0',
      exportDate: new Date().toISOString(),
      appName: 'Ballón dulces Klhoe',
      clients,
      inventory,
      invoices,
      rentals,
      pagoMovilConfig,
    };

    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(backup, null, 2)
    )}`;
    const downloadAnchor = document.createElement('a');
    const dateFormatted = new Date().toISOString().slice(0, 10);
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute(
      'download',
      `respaldo-ballon-dulces-klhoe-${dateFormatted}.json`
    );
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    const now = new Date().toLocaleString('es-VE');
    setLastBackupDate(now);
    localStorage.setItem('bdk_last_local_backup_date', now);
    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3500);
  };

  // Exportar Libro Excel Maestro Multi-Hojas
  const handleExportExcelMaster = () => {
    const wb = XLSX.utils.book_new();

    // Hoja 1: Clientes
    const clientsRows = clients.map((c) => ({
      ID: c.id,
      Nombre: c.name,
      'Cédula / RIF': c.cedulaRif || '',
      Teléfono: c.phone,
      Dirección: c.address,
      'Fecha Registro': c.createdAt.slice(0, 10),
    }));
    const wsClients = XLSX.utils.json_to_sheet(clientsRows);
    XLSX.utils.book_append_sheet(wb, wsClients, 'Clientes');

    // Hoja 2: Inventario
    const inventoryRows = inventory.map((inv) => ({
      ID: inv.id,
      Nombre: inv.name,
      Categoría: inv.category,
      Stock: inv.quantity,
      'Precio USD': inv.price,
      'Precio Bs (BCV)': Number((inv.price * currentRate).toFixed(2)),
      'Última Modificación': inv.updatedAt.slice(0, 10),
    }));
    const wsInventory = XLSX.utils.json_to_sheet(inventoryRows);
    XLSX.utils.book_append_sheet(wb, wsInventory, 'Inventario');

    // Hoja 3: Facturación
    const invoiceRows = invoices.map((i) => ({
      ID: i.id,
      'Nº Documento': i.documentNumber,
      Tipo: i.type,
      Estado: i.status,
      'Método de Pago': i.paymentMethod || 'Efectivo $',
      Cliente: i.clientName,
      'Total USD': i.totalUSD,
      'Tasa BCV': i.bcvRate,
      'Total Bs': i.totalBs,
      Fecha: i.issueDate,
    }));
    const wsInvoices = XLSX.utils.json_to_sheet(invoiceRows);
    XLSX.utils.book_append_sheet(wb, wsInvoices, 'Facturación');

    // Hoja 4: Alquileres y Devoluciones
    const rentalRows = rentals.map((r) => ({
      'Nº Alquiler': r.id,
      'Ref Factura': r.documentNumber,
      Cliente: r.clientName,
      Estado: r.status,
      'Despacho': r.dispatchDate,
      'Retorno Pactado': r.expectedReturnDate,
      'Garantía USD': r.depositAmountUSD,
      'Daños USD': r.totalDamageChargeUSD,
      'Reintegro USD': r.depositRefundUSD,
      'Pendiente Cobro USD': r.pendingChargeUSD,
      Locación: r.eventLocation,
    }));
    const wsRentals = XLSX.utils.json_to_sheet(rentalRows);
    XLSX.utils.book_append_sheet(wb, wsRentals, 'Alquileres');

    const dateFormatted = new Date().toISOString().slice(0, 10);
    XLSX.writeFile(wb, `libro-maestro-ballon-dulces-klhoe-${dateFormatted}.xlsx`);

    setDownloadSuccess(true);
    setTimeout(() => setDownloadSuccess(false), 3500);
  };

  // Leer y validar archivo JSON para restaurar
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setImportError(null);
    setImportPreview(null);
    setImportSuccess(false);

    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const parsed: BackupData = JSON.parse(text);

        if (!parsed.clients || !Array.isArray(parsed.clients) || !parsed.inventory || !Array.isArray(parsed.inventory)) {
          throw new Error('El archivo no tiene el formato de copia de seguridad válido de Ballón Dulces Klhoe.');
        }

        setImportPreview(parsed);
      } catch (err: any) {
        setImportError(err.message || 'Error al leer el archivo JSON seleccionado.');
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = () => {
    if (!importPreview) return;
    onRestoreData(importPreview);
    setImportSuccess(true);
    setImportPreview(null);
    setTimeout(() => setImportSuccess(false), 4000);
  };

  // Estadísticas generales del sistema
  const totalRecords = clients.length + inventory.length + invoices.length + rentals.length;

  return (
    <div className="space-y-6">
      {/* Encabezado */}
      <div className="bg-white/80 backdrop-blur-md p-6 rounded-3xl border border-stone-200/80 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="p-2 rounded-xl bg-purple-100 text-purple-700">
            <Database className="w-5 h-5" />
          </span>
          <h2 className="text-xl md:text-2xl font-bold font-script text-fuchsia-950">
            Copias de Seguridad, Respaldo y Restauración
          </h2>
        </div>
        <p className="text-xs text-stone-600 mt-1">
          Descarga copias de seguridad completas de toda tu información en tu equipo o restaura bases de datos anteriores de forma segura.
        </p>
      </div>

      {/* Indicadores de Salud de la Base de Datos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Registros Totales
            </span>
            <h3 className="text-2xl font-bold text-stone-900 mt-0.5">
              {totalRecords}
            </h3>
            <p className="text-[10px] text-stone-500">En clientes, stock y facturas</p>
          </div>
          <div className="p-3 bg-stone-100 text-stone-700 rounded-2xl">
            <HardDrive className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Directorio Clientes
            </span>
            <h3 className="text-2xl font-bold text-stone-900 mt-0.5">
              {clients.length}
            </h3>
            <p className="text-[10px] text-stone-500">Registrados en agenda</p>
          </div>
          <div className="p-3 bg-fuchsia-50 text-fuchsia-700 rounded-2xl">
            <Database className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Movimientos Facturación
            </span>
            <h3 className="text-2xl font-bold text-stone-900 mt-0.5">
              {invoices.length}
            </h3>
            <p className="text-[10px] text-stone-500">Facturas y presupuestos</p>
          </div>
          <div className="p-3 bg-red-50 text-red-600 rounded-2xl">
            <FileSpreadsheet className="w-6 h-6" />
          </div>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-stone-500">
              Último Respaldo Local
            </span>
            <h3 className="text-xs font-bold text-stone-800 mt-1 truncate">
              {lastBackupDate || 'Sin registro reciente'}
            </h3>
            <p className="text-[10px] text-emerald-600 font-semibold mt-0.5 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              Almacenamiento seguro
            </p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-700 rounded-2xl">
            <Clock className="w-6 h-6" />
          </div>
        </div>
      </div>

      {downloadSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-2xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>¡Archivo descargado exitosamente a tu dispositivo! Guárdalo en un pendrive o carpeta segura.</span>
        </div>
      )}

      {importSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-300 text-emerald-800 rounded-2xl text-xs flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>¡Copia de seguridad restaurada con éxito! Todos los módulos han sido actualizados con los datos importados.</span>
        </div>
      )}

      {/* Opciones de Exportación y Restauración */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* TARJETA 1: DESCARGAR COPIAS */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="border-b border-stone-200 pb-3">
            <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
              <Download className="w-5 h-5 text-fuchsia-950" />
              <span>Exportar Copias de Seguridad</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Descarga un archivo con fecha y hora para resguardar tus datos en caso de cambio de equipo o formateo.
            </p>
          </div>

          <div className="space-y-3">
            {/* Botón Respaldo JSON */}
            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="font-bold text-xs text-stone-900 flex items-center gap-1.5">
                  <FileJson className="w-4 h-4 text-fuchsia-800" />
                  <span>Respaldo Completo del Sistema (.JSON)</span>
                </h4>
                <p className="text-[11px] text-stone-500 mt-0.5">
                  Incluye clientes, inventario, facturas, alquileres e inspecciones listo para restaurar.
                </p>
              </div>

              <button
                type="button"
                onClick={handleExportJSON}
                className="px-4 py-2.5 bg-fuchsia-950 hover:bg-fuchsia-900 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>Descargar .JSON</span>
              </button>
            </div>

            {/* Botón Respaldo Excel Maestro */}
            <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="font-bold text-xs text-emerald-950 flex items-center gap-1.5">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
                  <span>Libro Maestro Completo (.XLSX)</span>
                </h4>
                <p className="text-[11px] text-emerald-800/80 mt-0.5">
                  Hojas individuales de Excel para Clientes, Inventario, Facturación y Alquileres.
                </p>
              </div>

              <button
                type="button"
                onClick={handleExportExcelMaster}
                className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors shrink-0"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Descargar Excel</span>
              </button>
            </div>
          </div>
        </div>

        {/* TARJETA 2: RESTAURAR COPIA */}
        <div className="bg-white p-6 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="border-b border-stone-200 pb-3">
            <h3 className="font-bold text-base text-stone-900 flex items-center gap-2">
              <Upload className="w-5 h-5 text-red-600" />
              <span>Restaurar Copia de Seguridad</span>
            </h3>
            <p className="text-xs text-stone-500 mt-0.5">
              Carga un archivo <code className="bg-stone-100 px-1 py-0.5 rounded font-mono">.json</code> descargado previamente para restaurar tu información.
            </p>
          </div>

          <div className="space-y-4">
            {/* Input para subir archivo */}
            <div className="border-2 border-dashed border-stone-200 hover:border-red-400 p-6 rounded-2xl text-center cursor-pointer transition-colors bg-stone-50">
              <input
                type="file"
                accept=".json"
                onChange={handleFileChange}
                className="hidden"
                id="restore-file-input"
              />
              <label htmlFor="restore-file-input" className="cursor-pointer space-y-2 block">
                <Upload className="w-8 h-8 text-stone-400 mx-auto" />
                <span className="block text-xs font-semibold text-stone-700">
                  Haz clic para seleccionar tu archivo de respaldo (.json)
                </span>
                <span className="block text-[11px] text-stone-400">
                  Formato JSON exportado desde Ballón Dulces Klhoe
                </span>
              </label>
            </div>

            {/* Error si ocurre */}
            {importError && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-800 rounded-xl text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{importError}</span>
              </div>
            )}

            {/* Vista previa antes de confirmar */}
            {importPreview && (
              <div className="p-4 bg-fuchsia-50/60 rounded-2xl border border-fuchsia-200 space-y-3 text-xs">
                <div className="flex items-center justify-between font-bold text-fuchsia-950">
                  <span>Respaldo Detectado:</span>
                  <span className="text-[11px] font-mono font-normal">
                    {new Date(importPreview.exportDate).toLocaleString('es-VE')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] text-stone-700 bg-white p-2.5 rounded-xl border border-fuchsia-100">
                  <div>• Clientes: <strong>{importPreview.clients?.length || 0}</strong></div>
                  <div>• Inventario: <strong>{importPreview.inventory?.length || 0}</strong></div>
                  <div>• Facturas: <strong>{importPreview.invoices?.length || 0}</strong></div>
                  <div>• Alquileres: <strong>{importPreview.rentals?.length || 0}</strong></div>
                </div>

                <div className="p-2 bg-amber-50 border border-amber-200 text-amber-900 rounded-xl text-[11px]">
                  ⚠️ <strong>Atención:</strong> Al restaurar, se actualizará la base de datos local con los registros del archivo seleccionado.
                </div>

                <div className="flex items-center justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setImportPreview(null)}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-semibold"
                  >
                    Cancelar
                  </button>
                  <button
                    type="button"
                    onClick={handleConfirmRestore}
                    className="px-4 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl font-semibold shadow-xs"
                  >
                    Confirmar y Restaurar
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
