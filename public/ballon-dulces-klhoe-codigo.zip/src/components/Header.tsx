import React from 'react';
import { Sparkles } from 'lucide-react';
import { User } from 'firebase/auth';
import { SyncStatusIndicator, SyncState } from './SyncStatusIndicator';

interface HeaderProps {
  bcvRate: number | null;
  loadingRate: boolean;
  onRefreshRate: () => void;
  activeModule: string;
  syncStatus: SyncState;
  lastSyncTime: string | null;
  lastSyncUrl: string | null;
  isSyncing: boolean;
  googleUser: User | null;
  onSyncNow: () => void;
  onGoogleSignIn: () => void;
  pendingCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  bcvRate,
  loadingRate,
  onRefreshRate,
  activeModule,
  syncStatus,
  lastSyncTime,
  lastSyncUrl,
  isSyncing,
  googleUser,
  onSyncNow,
  onGoogleSignIn,
  pendingCount,
}) => {
  return (
    <header className="no-print bg-white/95 backdrop-blur-md border-b border-fuchsia-100 sticky top-0 z-30 px-4 md:px-8 py-3 transition-all">
      <div className="flex items-center justify-between gap-3">
        {/* Mobile / Title preview */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-red-600 via-fuchsia-600 to-pink-500 flex items-center justify-center text-white shadow-md shadow-fuchsia-200 shrink-0">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-bold font-script text-fuchsia-950 tracking-wide leading-tight">
              Ballón dulces Klhoe
            </h1>
            <p className="text-xs text-fuchsia-700/80 hidden sm:block italic font-script">
              "Detalles que marcan la diferencia en tu fiesta"
            </p>
          </div>
        </div>

        {/* Sync Status & BCV Rate Indicator */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Indicador visual de Sincronización con Google Drive / Sheets */}
          <SyncStatusIndicator
            status={syncStatus}
            lastSyncTime={lastSyncTime}
            lastSyncUrl={lastSyncUrl}
            isSyncing={isSyncing}
            googleUser={googleUser}
            onSyncNow={onSyncNow}
            onGoogleSignIn={onGoogleSignIn}
            pendingCount={pendingCount}
          />

          {/* Tasa Oficial BCV */}
          <div className="bg-white border border-fuchsia-100 rounded-xl px-2.5 sm:px-3 py-1 flex items-center gap-2 shadow-xs">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-ping shrink-0" />
            <div className="text-right">
              <span className="text-[9px] uppercase tracking-wider font-semibold text-fuchsia-500 block leading-tight">
                Tasa BCV
              </span>
              <span className="text-xs sm:text-sm font-bold text-stone-800 font-mono leading-tight">
                {loadingRate ? (
                  <span className="text-stone-400 animate-pulse">...</span>
                ) : bcvRate ? (
                  `${bcvRate.toFixed(2)} Bs`
                ) : (
                  '36.50 Bs'
                )}
              </span>
            </div>
            <button
              onClick={onRefreshRate}
              disabled={loadingRate}
              title="Actualizar tasa oficial BCV"
              className="p-1 rounded-lg text-stone-400 hover:text-fuchsia-600 hover:bg-fuchsia-50 transition-colors cursor-pointer"
            >
              <svg
                className={`w-3.5 h-3.5 ${loadingRate ? 'animate-spin' : ''}`}
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
                />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
