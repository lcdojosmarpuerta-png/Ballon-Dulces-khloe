/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import { 
  Client, 
  InventoryItem, 
  InvoiceDocument, 
  RentalInspection, 
  PagoMovilConfig, 
  BackupData, 
  InvoiceItem 
} from './types';
import { 
  INITIAL_CLIENTS, 
  INITIAL_INVENTORY, 
  INITIAL_INVOICES, 
  INITIAL_RENTALS, 
  DEFAULT_PAGO_MOVIL 
} from './data/mockData';
import { initAuth, googleSignIn, logoutGoogle } from './lib/googleAuth';
import { exportInvoicesToExcel, exportInvoicesToGoogleSheets } from './lib/exportUtils';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { Header } from './components/Header';
import { SyncState } from './components/SyncStatusIndicator';
import { HomeView } from './components/HomeView';
import { ClientsModule } from './components/ClientsModule';
import { InventoryModule } from './components/InventoryModule';
import { InvoiceGenerator } from './components/InvoiceGenerator';
import { ReportsModule } from './components/ReportsModule';
import { RentalsModule } from './components/RentalsModule';
import { WhatsAppCobranzasModule } from './components/WhatsAppCobranzasModule';
import { CatalogModule } from './components/CatalogModule';
import { BackupsModule } from './components/BackupsModule';
import { EndOfMonthModal } from './components/EndOfMonthModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('inicio');

  // Google Auth State
  const [googleUser, setGoogleUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Google Drive & Sheets Sync State
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(() => {
    return localStorage.getItem('bdk_last_sync_time');
  });

  const [lastSyncUrl, setLastSyncUrl] = useState<string | null>(() => {
    return localStorage.getItem('bdk_last_sync_url');
  });

  const [hasPendingChanges, setHasPendingChanges] = useState<boolean>(() => {
    const saved = localStorage.getItem('bdk_has_pending_sync');
    if (saved !== null) {
      return saved === 'true';
    }
    return !localStorage.getItem('bdk_last_sync_time');
  });

  const [isSyncing, setIsSyncing] = useState<boolean>(false);

  // Guardar estado de cambios pendientes
  useEffect(() => {
    localStorage.setItem('bdk_has_pending_sync', String(hasPendingChanges));
  }, [hasPendingChanges]);

  // BCV Rate State
  const [bcvRate, setBcvRate] = useState<number | null>(36.5);
  const [loadingRate, setLoadingRate] = useState(false);

  // Local Storage Data Collections
  const [clients, setClients] = useState<Client[]>(() => {
    const saved = localStorage.getItem('bdk_clients');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading clients:', e);
      }
    }
    return INITIAL_CLIENTS;
  });

  const [inventory, setInventory] = useState<InventoryItem[]>(() => {
    const saved = localStorage.getItem('bdk_inventory');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading inventory:', e);
      }
    }
    return INITIAL_INVENTORY;
  });

  const [invoices, setInvoices] = useState<InvoiceDocument[]>(() => {
    const saved = localStorage.getItem('bdk_invoices');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading invoices:', e);
      }
    }
    return INITIAL_INVOICES;
  });

  // Opción 1: Control de Alquileres & Devoluciones
  const [rentals, setRentals] = useState<RentalInspection[]>(() => {
    const saved = localStorage.getItem('bdk_rentals');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading rentals:', e);
      }
    }
    return INITIAL_RENTALS;
  });

  // Opción 2: Configuración de Pago Móvil & QR
  const [pagoMovilConfig, setPagoMovilConfig] = useState<PagoMovilConfig>(() => {
    const saved = localStorage.getItem('bdk_pago_movil');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Error loading pagoMovilConfig:', e);
      }
    }
    return DEFAULT_PAGO_MOVIL;
  });

  // Opción 3: Ítems transferidos desde Catálogo a Facturación
  const [catalogItemsToImport, setCatalogItemsToImport] = useState<InvoiceItem[] | null>(null);

  // Invoice being edited from reports
  const [invoiceToEdit, setInvoiceToEdit] = useState<InvoiceDocument | null>(null);

  // End of month modal trigger
  const [showEndOfMonthModal, setShowEndOfMonthModal] = useState(false);
  const [appToast, setAppToast] = useState<string | null>(null);

  const showAppToast = (msg: string) => {
    setAppToast(msg);
    setTimeout(() => setAppToast(null), 3500);
  };

  // Guardar en localStorage ante cambios
  useEffect(() => {
    localStorage.setItem('bdk_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    localStorage.setItem('bdk_inventory', JSON.stringify(inventory));
  }, [inventory]);

  useEffect(() => {
    localStorage.setItem('bdk_invoices', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('bdk_rentals', JSON.stringify(rentals));
  }, [rentals]);

  useEffect(() => {
    localStorage.setItem('bdk_pago_movil', JSON.stringify(pagoMovilConfig));
  }, [pagoMovilConfig]);

  // Obtener Tasa Oficial BCV usando ve.dolarapi.com/v1/dolares/oficial
  const fetchBcvRate = async () => {
    try {
      setLoadingRate(true);
      const res = await fetch('https://ve.dolarapi.com/v1/dolares/oficial');
      if (res.ok) {
        const data = await res.json();
        if (data && typeof data.promedio === 'number') {
          setBcvRate(data.promedio);
          localStorage.setItem('bdk_bcv_rate', String(data.promedio));
        }
      }
    } catch (err) {
      console.warn('No se pudo conectar a ve.dolarapi.com, usando valor almacenado o de respaldo.', err);
      const savedRate = localStorage.getItem('bdk_bcv_rate');
      if (savedRate) {
        setBcvRate(parseFloat(savedRate) || 36.5);
      }
    } finally {
      setLoadingRate(false);
    }
  };

  useEffect(() => {
    fetchBcvRate();
  }, []);

  // Verificar si hoy es el último día del mes en curso y si ya comenzó nuevo mes para reiniciar
  useEffect(() => {
    const now = new Date();
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth(); // 0-indexed

    // Último día del mes actual: día 0 del mes siguiente
    const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const isLastDay = now.getDate() === lastDayOfMonth;

    // Clave para evitar molestar múltiples veces el mismo día si el usuario ya lo cerró
    const lastPromptKey = `bdk_last_month_prompt_${currentYear}_${currentMonth}_${now.getDate()}`;
    const alreadyShownToday = sessionStorage.getItem(lastPromptKey);

    if (isLastDay && !alreadyShownToday) {
      setShowEndOfMonthModal(true);
      sessionStorage.setItem(lastPromptKey, 'true');
    }

    // Reiniciar datos al inicio de cada mes (Día 1 del mes):
    // Verificamos si cambió el mes respecto al último mes registrado
    const lastRecordedMonthKey = 'bdk_last_active_month';
    const lastRecordedMonth = localStorage.getItem(lastRecordedMonthKey);
    const thisMonthString = `${currentYear}-${currentMonth + 1}`;

    if (lastRecordedMonth && lastRecordedMonth !== thisMonthString && now.getDate() === 1) {
      // Es el primer día de un nuevo mes y el mes anterior era diferente
      // Reiniciamos los movimientos del mes (facturas)
      setInvoices([]);
      localStorage.setItem(lastRecordedMonthKey, thisMonthString);
      console.log('Inicio de mes detectado: Base de movimientos mensuales restablecida.');
    } else if (!lastRecordedMonth) {
      localStorage.setItem(lastRecordedMonthKey, thisMonthString);
    }
  }, []);

  // Inicializar Google Auth
  useEffect(() => {
    const unsubscribe = initAuth(
      (user) => setGoogleUser(user),
      () => setGoogleUser(null)
    );
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  const handleGoogleSignIn = async () => {
    try {
      setIsLoggingIn(true);
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
      }
    } catch (err: any) {
      console.error(err);
      showAppToast('⚠️ No se pudo completar el inicio de sesión con Google: ' + (err.message || 'Error'));
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleGoogleSignOut = async () => {
    await logoutGoogle();
    setGoogleUser(null);
  };

  // Acciones de Clientes
  const handleAddClient = (newClientData: Omit<Client, 'id' | 'createdAt'>) => {
    const newClient: Client = {
      ...newClientData,
      id: `cli-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setClients([newClient, ...clients]);
    setHasPendingChanges(true);
  };

  const handleUpdateClient = (updated: Client) => {
    setClients(clients.map((c) => (c.id === updated.id ? updated : c)));
    setHasPendingChanges(true);
  };

  const handleDeleteClient = (id: string) => {
    setClients(clients.filter((c) => c.id !== id));
    setHasPendingChanges(true);
  };

  // Acciones de Inventario
  const handleAddInventoryItem = (itemData: Omit<InventoryItem, 'id' | 'updatedAt'>) => {
    const newItem: InventoryItem = {
      ...itemData,
      id: `inv-${Date.now()}`,
      updatedAt: new Date().toISOString(),
    };
    setInventory([newItem, ...inventory]);
    setHasPendingChanges(true);
  };

  const handleUpdateInventoryItem = (updated: InventoryItem) => {
    setInventory(inventory.map((item) => (item.id === updated.id ? updated : item)));
    setHasPendingChanges(true);
  };

  const handleDeleteInventoryItem = (id: string) => {
    setInventory(inventory.filter((item) => item.id !== id));
    setHasPendingChanges(true);
  };

  // Acciones de Facturación
  const handleSaveInvoice = (invoiceDoc: InvoiceDocument) => {
    const existingIndex = invoices.findIndex((i) => i.id === invoiceDoc.id);
    if (existingIndex >= 0) {
      const updated = [...invoices];
      updated[existingIndex] = invoiceDoc;
      setInvoices(updated);
    } else {
      setInvoices([invoiceDoc, ...invoices]);
    }

    // Auto-agregar o actualizar en el Módulo de Control de Alquileres & Retiros
    const rentalItems = invoiceDoc.items
      .filter((it) => it.quantity > 0)
      .map((it) => ({
        inventoryId: it.inventoryId,
        name: it.name,
        quantity: it.quantity,
        category: it.category,
      }));

    if (rentalItems.length > 0) {
      const existingRentalIndex = rentals.findIndex(
        (r) => r.invoiceId === invoiceDoc.id || r.documentNumber === invoiceDoc.documentNumber
      );

      const eventDateToUse = invoiceDoc.eventDate || invoiceDoc.issueDate || new Date().toISOString().slice(0, 10);
      const [year, month, day] = eventDateToUse.split('-').map(Number);
      const eventD = new Date(year, month - 1, day);
      eventD.setDate(eventD.getDate() + 1);
      const nextYear = eventD.getFullYear();
      const nextMonth = String(eventD.getMonth() + 1).padStart(2, '0');
      const nextDay = String(eventD.getDate()).padStart(2, '0');
      const expectedReturn = `${nextYear}-${nextMonth}-${nextDay}`;

      if (existingRentalIndex >= 0) {
        const updatedRentals = [...rentals];
        updatedRentals[existingRentalIndex] = {
          ...updatedRentals[existingRentalIndex],
          clientName: invoiceDoc.clientName,
          clientPhone: invoiceDoc.clientPhone,
          clientCedulaRif: invoiceDoc.clientCedulaRif,
          eventLocation: invoiceDoc.clientAddress || 'Dirección del cliente',
          dispatchDate: eventDateToUse,
          expectedReturnDate: expectedReturn,
          itemsDispatched: rentalItems,
        };
        setRentals(updatedRentals);
      } else {
        const newRental: RentalInspection = {
          id: `ALQ-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
          invoiceId: invoiceDoc.id,
          documentNumber: invoiceDoc.documentNumber,
          clientId: invoiceDoc.clientId,
          clientName: invoiceDoc.clientName,
          clientPhone: invoiceDoc.clientPhone,
          clientCedulaRif: invoiceDoc.clientCedulaRif,
          eventLocation: invoiceDoc.clientAddress || 'Dirección del cliente',
          dispatchDate: eventDateToUse,
          expectedReturnDate: expectedReturn,
          depositAmountUSD: 30,
          status: 'En Evento (Calle)',
          itemsDispatched: rentalItems,
          damages: [],
          totalDamageChargeUSD: 0,
          depositRefundUSD: 30,
          pendingChargeUSD: 0,
          inspectionNotes: `Registrado automáticamente desde ${invoiceDoc.type} ${invoiceDoc.documentNumber}. Fecha Evento: ${eventDateToUse}`,
          inspectedBy: 'Lcdo. Josmar Puerta',
          createdAt: new Date().toISOString(),
        };
        setRentals([newRental, ...rentals]);
      }
    }

    setInvoiceToEdit(null);
    setHasPendingChanges(true);
    showAppToast(`✅ Documento ${invoiceDoc.documentNumber} guardado y agregado a Control de Alquileres & Retiros.`);
  };

  const handleDeleteInvoice = (id: string) => {
    setInvoices(invoices.filter((inv) => inv.id !== id));
    setRentals(rentals.filter((r) => r.invoiceId !== id));
    setHasPendingChanges(true);
  };

  const handleEditInvoiceFromReports = (inv: InvoiceDocument) => {
    setInvoiceToEdit(inv);
    setActiveTab('facturacion');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleResetMonthlyData = () => {
    setInvoices([]);
    setHasPendingChanges(true);
  };

  // Acciones de Alquileres e Inspecciones (Opción 1)
  const handleAddRental = (rental: RentalInspection) => {
    setRentals([rental, ...rentals]);
    setHasPendingChanges(true);
    showAppToast('✅ Despacho de alquiler registrado exitosamente.');
  };

  const handleUpdateRental = (updated: RentalInspection) => {
    setRentals(rentals.map((r) => (r.id === updated.id ? updated : r)));
    setHasPendingChanges(true);
    showAppToast('✅ Acta de devolución e inspección guardada.');
  };

  const handleDeleteRental = (id: string) => {
    setRentals(rentals.filter((r) => r.id !== id));
    setHasPendingChanges(true);
    showAppToast('🗑️ Registro de alquiler eliminado.');
  };

  // Configuración de Pago Móvil & QR (Opción 2)
  const handleUpdatePagoMovilConfig = (config: PagoMovilConfig) => {
    setPagoMovilConfig(config);
    showAppToast('✅ Datos de Pago Móvil actualizados correctamente.');
  };

  // Transferencia de ítems desde el Catálogo a Facturación (Opción 3)
  const handleTransferCatalogToInvoice = (
    items: { inventoryId?: string; name: string; quantity: number; unitPrice: number; category?: string }[]
  ) => {
    const mapped: InvoiceItem[] = items.map((it, idx) => ({
      id: `it-cat-${Date.now()}-${idx}`,
      inventoryId: it.inventoryId,
      name: it.name,
      category: it.category,
      quantity: it.quantity,
      unitPrice: it.unitPrice,
      total: it.quantity * it.unitPrice,
    }));
    setCatalogItemsToImport(mapped);
    setActiveTab('facturacion');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Restauración de Copia de Seguridad Completa (Opción 5)
  const handleRestoreData = (backup: BackupData) => {
    if (backup.clients) setClients(backup.clients);
    if (backup.inventory) setInventory(backup.inventory);
    if (backup.invoices) setInvoices(backup.invoices);
    if (backup.rentals) setRentals(backup.rentals);
    if (backup.pagoMovilConfig) setPagoMovilConfig(backup.pagoMovilConfig);
    setHasPendingChanges(true);
    showAppToast('🎉 Copia de seguridad restaurada exitosamente.');
  };

  // Sincronización directa con Google Drive & Sheets desde el Header
  const handleSyncToGoogleSheets = async () => {
    if (!googleUser) {
      await handleGoogleSignIn();
      return;
    }

    if (invoices.length === 0) {
      showAppToast('⚠️ No hay movimientos registrados para sincronizar.');
      return;
    }

    try {
      setIsSyncing(true);
      const res = await exportInvoicesToGoogleSheets(
        invoices,
        'Reporte Movimientos Ballón Dulces Klhoe'
      );
      const now = new Date().toISOString();
      setLastSyncTime(now);
      localStorage.setItem('bdk_last_sync_time', now);
      setLastSyncUrl(res.spreadsheetUrl);
      localStorage.setItem('bdk_last_sync_url', res.spreadsheetUrl);
      setHasPendingChanges(false);
      localStorage.setItem('bdk_has_pending_sync', 'false');
      showAppToast('✅ Sincronizado exitosamente con tu Google Sheets');
    } catch (err: any) {
      console.error('Error al sincronizar con Google Sheets:', err);
      showAppToast(`⚠️ Error al sincronizar: ${err.message || 'Desconocido'}`);
    } finally {
      setIsSyncing(false);
    }
  };

  // Estado calculado de sincronización
  const syncStatus: SyncState = isSyncing
    ? 'syncing'
    : hasPendingChanges || !lastSyncTime
    ? 'pending'
    : 'synced';

  // Total de ingresos del mes para el dashboard de inicio
  const totalIncomeUSD = invoices
    .filter((inv) => inv.type === 'Factura' || inv.type === 'Nota de Entrega')
    .reduce((acc, curr) => acc + curr.totalUSD, 0);

  return (
    <div className="min-h-screen abstract-line-bg flex flex-col md:flex-row text-stone-800">
      {/* Barra Lateral Fija Izquierda */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab !== 'facturacion') {
            setInvoiceToEdit(null);
          }
        }}
        googleUser={googleUser}
        onGoogleSignIn={handleGoogleSignIn}
        onGoogleSignOut={handleGoogleSignOut}
        isLoggingIn={isLoggingIn}
      />

      {/* Área de Trabajo Principal */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <Header
          bcvRate={bcvRate}
          loadingRate={loadingRate}
          onRefreshRate={fetchBcvRate}
          activeModule={activeTab}
          syncStatus={syncStatus}
          lastSyncTime={lastSyncTime}
          lastSyncUrl={lastSyncUrl}
          isSyncing={isSyncing}
          googleUser={googleUser}
          onSyncNow={handleSyncToGoogleSheets}
          onGoogleSignIn={handleGoogleSignIn}
          pendingCount={invoices.length}
        />

        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          {activeTab === 'inicio' && (
            <HomeView
              setActiveTab={setActiveTab}
              clientsCount={clients.length}
              inventoryCount={inventory.length}
              invoicesCount={invoices.length}
              bcvRate={bcvRate}
              totalIncomeUSD={totalIncomeUSD}
              rentalsCount={rentals.length}
            />
          )}

          {activeTab === 'clientes' && (
            <ClientsModule
              clients={clients}
              onAddClient={handleAddClient}
              onUpdateClient={handleUpdateClient}
              onDeleteClient={handleDeleteClient}
            />
          )}

          {activeTab === 'inventario' && (
            <InventoryModule
              inventory={inventory}
              onAddItem={handleAddInventoryItem}
              onUpdateItem={handleUpdateInventoryItem}
              onDeleteItem={handleDeleteInventoryItem}
            />
          )}

          {activeTab === 'facturacion' && (
            <InvoiceGenerator
              clients={clients}
              inventory={inventory}
              rentals={rentals}
              bcvRate={bcvRate}
              onSaveInvoice={handleSaveInvoice}
              activeInvoiceToEdit={invoiceToEdit}
              onFinishEdit={() => setInvoiceToEdit(null)}
              catalogItemsToImport={catalogItemsToImport}
              onClearCatalogImport={() => setCatalogItemsToImport(null)}
            />
          )}

          {activeTab === 'alquileres' && (
            <RentalsModule
              rentals={rentals}
              clients={clients}
              inventory={inventory}
              invoices={invoices}
              bcvRate={bcvRate}
              onAddRental={handleAddRental}
              onUpdateRental={handleUpdateRental}
              onDeleteRental={handleDeleteRental}
            />
          )}

          {activeTab === 'mensajes' && (
            <WhatsAppCobranzasModule
              clients={clients}
              invoices={invoices}
              bcvRate={bcvRate}
              pagoMovilConfig={pagoMovilConfig}
              onUpdatePagoMovilConfig={handleUpdatePagoMovilConfig}
            />
          )}

          {activeTab === 'catalogo' && (
            <CatalogModule
              inventory={inventory}
              rentals={rentals}
              bcvRate={bcvRate}
              onTransferToInvoice={handleTransferCatalogToInvoice}
            />
          )}

          {activeTab === 'reportes' && (
            <ReportsModule
              invoices={invoices}
              onDeleteInvoice={handleDeleteInvoice}
              onEditInvoice={handleEditInvoiceFromReports}
              onResetMonthlyData={handleResetMonthlyData}
              googleUser={googleUser}
              onGoogleSignIn={handleGoogleSignIn}
              lastSyncUrl={lastSyncUrl}
              onSyncedSuccess={(url) => {
                const now = new Date().toISOString();
                setLastSyncTime(now);
                localStorage.setItem('bdk_last_sync_time', now);
                setLastSyncUrl(url);
                localStorage.setItem('bdk_last_sync_url', url);
                setHasPendingChanges(false);
                localStorage.setItem('bdk_has_pending_sync', 'false');
              }}
            />
          )}

          {activeTab === 'respaldos' && (
            <BackupsModule
              clients={clients}
              inventory={inventory}
              invoices={invoices}
              rentals={rentals}
              pagoMovilConfig={pagoMovilConfig}
              bcvRate={bcvRate}
              onRestoreData={handleRestoreData}
            />
          )}
        </main>
      </div>

      {/* Modal Emergente Último Día del Mes */}
      <EndOfMonthModal
        isOpen={showEndOfMonthModal}
        onClose={() => setShowEndOfMonthModal(false)}
        onExportExcel={() => {
          const monthName = new Date().toLocaleString('es-VE', { month: 'long', year: 'numeric' });
          exportInvoicesToExcel(invoices, monthName);
        }}
      />

      {/* Global App Toast */}
      {appToast && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-3 border border-stone-800 text-sm no-print animate-fadeIn">
          <span>{appToast}</span>
        </div>
      )}
    </div>
  );
}
